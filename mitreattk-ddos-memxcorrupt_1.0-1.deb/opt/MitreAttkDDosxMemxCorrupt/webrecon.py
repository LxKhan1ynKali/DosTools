#!/usr/bin/env python3
"""
site_info.py
Author: khaninkali

Usage:
    python3 site_info.py <url_or_domain>

Features:
- WHOIS lookup for domain
- DNS records (A, AAAA, MX, NS, TXT, CNAME) using dnspython if available
- IP resolution (A/AAAA) and reverse DNS (PTR)
- HTTP(S) request: headers, redirects, final URL, basic CDN/Cloudflare detection

Requires:
- Python 3
- requests
- Optional: dnspython (for richer DNS info)
"""

import sys
import socket
import subprocess
from urllib.parse import urlparse

import requests

try:
    import dns.resolver
    HAS_DNSPYTHON = True
except ImportError:
    HAS_DNSPYTHON = False


# --------- Helpers --------- #

def normalize_url_or_domain(target: str):
    """Return (url, domain) where url is usable by requests and domain is bare domain."""
    target = target.strip()
    if "://" not in target:
        url = "http://" + target
    else:
        url = target

    parsed = urlparse(url)
    host = parsed.netloc or parsed.path
    host = host.split(":")[0]

    # simple domain extraction: strip leading subdomains like "www."
    parts = host.split(".")
    if len(parts) > 2:
        domain = ".".join(parts[-2:])
    else:
        domain = host

    return url, domain


def run_whois(domain: str) -> str:
    try:
        result = subprocess.run(
            ["whois", domain],
            capture_output=True,
            text=True,
            timeout=20,
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout
        return f"[!] whois command failed (code {result.returncode}). stderr:\n{result.stderr}"
    except FileNotFoundError:
        return "[!] whois command not found on this system."
    except subprocess.TimeoutExpired:
        return "[!] whois command timed out."


def resolve_ips(domain: str):
    """Resolve IPs using socket.getaddrinfo (A + AAAA)."""
    ips = set()
    errors = []
    try:
        infos = socket.getaddrinfo(domain, None)
        for info in infos:
            ip = info[4][0]
            ips.add(ip)
    except Exception as e:
        errors.append(str(e))
    return sorted(ips), errors


def reverse_dns(ip: str):
    try:
        host, _, _ = socket.gethostbyaddr(ip)
        return host
    except Exception:
        return None


def dns_query(domain: str, rtype: str):
    """Query DNS records of given type using dnspython if available."""
    if not HAS_DNSPYTHON:
        return [], "[!] dnspython not installed, DNS record listing limited."
    try:
        answers = dns.resolver.resolve(domain, rtype)
        return [str(rdata) for rdata in answers], None
    except Exception as e:
        return [], str(e)


def fetch_http_info(url: str):
    try:
        resp = requests.get(url, timeout=15, allow_redirects=True)
    except Exception as e:
        return {"error": str(e)}

    chain = [r.url for r in resp.history] + [resp.url]

    return {
        "final_url": resp.url,
        "status_code": resp.status_code,
        "redirect_chain": chain,
        "headers": dict(resp.headers),
    }


def detect_cdn_from_headers(headers: dict):
    """Very simple heuristics to spot CDNs / Cloudflare."""
    if not headers:
        return {"cloudflare": False, "cdn_hint": None}

    h_lower = {k.lower(): v.lower() for k, v in headers.items()}
    server = h_lower.get("server", "")

    cloudflare = "cloudflare" in server
    if not cloudflare:
        # also look for CF headers
        for k in h_lower:
            if k.startswith("cf-"):
                cloudflare = True
                break

    cdn_hint = None
    # crude checks for other CDNs
    if "akamai" in server:
        cdn_hint = "Akamai (from Server header)"
    elif "fastly" in server:
        cdn_hint = "Fastly (from Server header)"
    elif "cloudfront" in server or "amazon" in server:
        cdn_hint = "Amazon CloudFront (from Server header)"
    elif "cloudflare" in server:
        cdn_hint = "Cloudflare (from Server header)"

    return {"cloudflare": cloudflare, "cdn_hint": cdn_hint}


# --------- Report functions --------- #

def print_whois(domain: str):
    print("=== WHOIS ===")
    data = run_whois(domain)
    print(data)
    print()


def print_dns(domain: str):
    print("=== DNS RECORDS ===")
    if not HAS_DNSPYTHON:
        print("[!] dnspython not installed, showing only basic IP resolution")
        print("    Install: pip install dnspython")
    else:
        for rtype in ["A", "AAAA", "MX", "NS", "TXT", "CNAME"]:
            records, err = dns_query(domain, rtype)
            print(f"\n{rtype} records:")
            if records:
                for r in records:
                    print("  ", r)
            else:
                print("   (none or error)")
                if err:
                    print("   error:", err)
    print()


def print_ips(domain: str):
    print("=== IP RESOLUTION ===")
    ips, errors = resolve_ips(domain)
    if ips:
        for ip in ips:
            rdns = reverse_dns(ip)
            print(f"- IP: {ip}")
            print(f"  PTR (rDNS): {rdns or '-'}")
    else:
        print("[!] No IPs resolved.")
    if errors:
        print("[!] DNS resolution errors:")
        for e in errors:
            print("   ", e)
    print()


def print_http(url: str):
    print("=== HTTP / HTTPS INFO ===")
    info = fetch_http_info(url)
    if "error" in info:
        print(f"[!] HTTP request error: {info['error']}")
        print()
        return

    print(f"Final URL: {info['final_url']}")
    print(f"Status code: {info['status_code']}")
    if len(info["redirect_chain"]) > 1:
        print("Redirect chain:")
        for u in info["redirect_chain"]:
            print("  ->", u)

    cdn = detect_cdn_from_headers(info["headers"])
    print()
    print(f"Cloudflare detected (headers)? {'yes' if cdn['cloudflare'] else 'no'}")
    if cdn["cdn_hint"]:
        print(f"Possible CDN: {cdn['cdn_hint']}")

    print("\n--- Response headers ---")
    for k, v in sorted(info["headers"].items()):
        print(f"{k}: {v}")
    print()


def print_note():
    print("=== NOTE ===")
    print(
        "This tool provides OSINT-style information only:\n"
        "- Public WHOIS data\n"
        "- Public DNS records\n"
        "- Publicly resolvable IPs and reverse DNS\n"
        "- HTTP(S) headers and simple CDN/Cloudflare indication\n\n"
        "It does not attempt to bypass Cloudflare or reveal hidden origin IPs."
    )
    print()


def main():
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} <url_or_domain>")
        sys.exit(1)

    target = sys.argv[1]
    url, domain = normalize_url_or_domain(target)

    print("=" * 60)
    print(f"Target: {target}")
    print(f"Normalized URL: {url}")
    print(f"Domain: {domain}")
    print("=" * 60)
    print()

    print_whois(domain)
    print_dns(domain)
    print_ips(domain)
    print_http(url)
    print_note()


if __name__ == "__main__":
    main()
